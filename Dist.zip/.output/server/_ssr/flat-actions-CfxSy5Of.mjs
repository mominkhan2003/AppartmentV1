import { n as api } from "./api-Bz4c_dXI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/flat-actions-CfxSy5Of.js
var pageHead = (title, description) => ({ meta: [
	{ title: `${title} — FlatMate Hub` },
	{
		name: "description",
		content: description
	},
	{
		property: "og:title",
		content: `${title} — FlatMate Hub`
	},
	{
		property: "og:description",
		content: description
	},
	{
		property: "og:type",
		content: "website"
	},
	{
		name: "twitter:card",
		content: "summary_large_image"
	}
] });
var login = (email, password) => api.post("/auth/login", {
	email,
	password
});
var signup = (email, password, display_name) => api.post("/auth/signup", {
	email,
	password,
	display_name
});
var logout = () => api.post("/auth/logout");
var changePassword = (current_password, new_password) => api.post("/auth/change-password", {
	current_password,
	new_password
});
var changeEmail = (new_email, current_password) => api.post("/auth/change-email", {
	new_email,
	current_password
});
var requestPasswordReset = (email) => api.post("/auth/request-password-reset", { email });
var resetPassword = (token, new_password) => api.post("/auth/reset-password", {
	token,
	new_password
});
function recordSharedExpense(d, opts) {
	const form = new FormData();
	form.append("title", opts.title);
	form.append("description", String(d.get("description") ?? ""));
	form.append("category", String(d.get("category") ?? "general"));
	form.append("amount_cents", String(opts.amountCents));
	form.append("expense_date", String(d.get("date") ?? ""));
	form.append("group_id", opts.group);
	if (opts.customShares) for (const [residentId, cents] of Object.entries(opts.customShares)) form.append(`custom[${residentId}]`, String(cents));
	else for (const id of opts.participants) form.append("participants[]", id);
	if (opts.receiptId) form.append("receipt_media_id", opts.receiptId);
	if (opts.receiptHash) form.append("receipt_hash", opts.receiptHash);
	const notes = String(d.get("notes") ?? "");
	if (notes) form.append("notes", notes);
	return api.post("/expenses/shared", form);
}
function submitClaim(d, opts) {
	const form = new FormData();
	form.append("title", opts.title);
	form.append("description", String(d.get("description") ?? ""));
	form.append("category", String(d.get("category") ?? "general"));
	form.append("amount_cents", String(opts.amountCents));
	form.append("expense_date", String(d.get("date") ?? ""));
	form.append("payer_resident_id", opts.payerResidentId);
	form.append("group_id", opts.group);
	if (opts.receiptId) form.append("receipt_media_id", opts.receiptId);
	if (opts.receiptHash) form.append("receipt_hash", opts.receiptHash);
	const notes = String(d.get("notes") ?? "");
	if (notes) form.append("notes", notes);
	return api.post("/expenses/claim", form);
}
var reviewClaim = (expenseId, approve, note) => api.post(`/expenses/${expenseId}/review`, {
	approve,
	note
});
var voidExpense = (expenseId, reason) => api.post(`/expenses/${expenseId}/void`, { reason });
var recordPayment = (residentId, amountCents, note) => api.post("/payments", {
	resident_id: residentId,
	amount_cents: amountCents,
	note
});
var addAdjustment = (residentId, amountCents, reason) => api.post("/adjustments", {
	resident_id: residentId,
	amount_cents: amountCents,
	reason
});
function saveChore(d, opts) {
	const form = new FormData();
	form.append("name", String(d.get("name") ?? ""));
	form.append("kind", String(d.get("kind") ?? "other"));
	form.append("space_id", String(d.get("space") ?? ""));
	form.append("frequency_days", String(d.get("frequency") ?? ""));
	form.append("next_due", String(d.get("due") ?? ""));
	form.append("rotates", d.get("rotates") === "on" ? "1" : "0");
	form.append("active", d.get("active") === "on" ? "1" : "0");
	form.append("current_resident_id", String(d.get("assigned") ?? ""));
	for (const m of opts.members) form.append("members[]", m);
	return opts.choreId ? api.patch(`/chores/${opts.choreId}`, form) : api.post("/chores", form);
}
var completeChore = (choreId, d, photo) => {
	const form = new FormData();
	const note = String(d.get("notes") ?? "");
	if (note) form.append("note", note);
	if (photo) form.append("file", photo);
	return api.post(`/chores/${choreId}/complete`, form);
};
var reportChoreNeeded = (choreId, note) => api.post(`/chores/${choreId}/report-needed`, { note });
var choreAdminAction = (choreId, action, target, reason) => api.post(`/chores/${choreId}/admin-action`, {
	action,
	target: target || null,
	reason
});
function createIssue(d, opts) {
	const form = new FormData();
	form.append("description", String(d.get("description") ?? ""));
	form.append("category", String(d.get("category") || "other"));
	form.append("space_id", String(d.get("space") ?? ""));
	if (opts.reporterResidentId) form.append("reporter_resident_id", opts.reporterResidentId);
	if (opts.photo) form.append("file", opts.photo);
	return api.post("/issues", form);
}
var updateIssue = (id, values) => api.patch(`/issues/${id}`, values);
var createResident = (values) => api.post("/residents", pick(values));
var updateResident = (id, values) => api.patch(`/residents/${id}`, pick(values));
function pick(values) {
	return {
		display_name: values.display_name ?? void 0,
		phone: values.phone ?? void 0,
		email: values.email ?? void 0,
		room_id: values.room_id ?? void 0,
		active: values.active ?? void 0
	};
}
var saveGroup = (id, values) => id ? api.patch(`/groups/${id}`, values) : api.post("/groups", values);
var saveSpace = (id, values) => api.patch(`/spaces/${id}`, values);
/** Replaces the whole bedroom→washrooms mapping (mirrors the old upsert+delete pair). */
var setWashroomAccessBulk = (bedroomId, washroomIds) => api.put("/washroom-access/bulk", {
	bedroom_id: bedroomId,
	washroom_ids: washroomIds
});
var portalRoles = () => api.get("/portal-roles");
var savePortalRole = (id, values) => id ? api.patch(`/portal-roles/${id}`, values) : api.post("/portal-roles", values);
var deletePortalRole = (id) => api.del(`/portal-roles/${id}`);
var assignPortalRoles = (residentId, roles) => api.post(`/residents/${residentId}/roles`, { roles });
var setAdmin = (residentId, makeAdmin) => api.post(`/residents/${residentId}/admin`, { make_admin: makeAdmin });
var hubItems = (kind) => api.get(`/hub/items?kind=${encodeURIComponent(kind)}`);
var hubResponses = (kind) => api.get(`/hub/responses?kind=${encodeURIComponent(kind)}`);
var hubInsert = (values) => api.post("/hub/items", values);
var hubEdit = (itemId, values) => api.patch(`/hub/items/${itemId}`, values);
var hubDelete = (itemId) => api.del(`/hub/items/${itemId}`);
var hubRespond = (itemId, value) => api.post("/hub/respond", {
	item_id: itemId,
	value
});
var hubSetStatus = (itemId, status) => api.post("/hub/status", {
	item_id: itemId,
	status
});
/** Admin/library upload into any bucket (receipts/photos remain open to residents too). */
var uploadMedia = (bucket, file) => {
	if (file.size > 10485760) throw new Error("Please choose a file smaller than 10 MB");
	const form = new FormData();
	form.append("file", file);
	return api.post(`/media?bucket=${bucket}`, form);
};
var updateMediaMeta = (id, values) => api.patch(`/media/${id}`, values);
var replaceMedia = (id, file) => {
	const form = new FormData();
	form.append("file", file);
	return api.put(`/media/${id}/replace`, form);
};
var deleteMedia = (id) => api.del(`/media/${id}`);
var listMedia = (params) => {
	const search = new URLSearchParams();
	if (params.bucket) search.set("bucket", params.bucket);
	if (params.q) search.set("q", params.q);
	if (params.page) search.set("page", String(params.page));
	if (params.per_page) search.set("per_page", String(params.per_page));
	const query = search.toString();
	return api.get("/media" + (query ? `?${query}` : ""));
};
var siteContent = () => api.get("/site-content");
var saveSiteSection = (code, values) => api.patch(`/site-content/${code}`, values);
var reorderSections = (codes, area) => api.post("/site-content/reorder", {
	codes,
	area
});
var siteSettings = () => api.get("/site-settings");
var saveSiteSettings = (values) => api.put("/site-settings", values);
var listEvents = (params = {}) => {
	const search = new URLSearchParams();
	if (params.status) search.set("status", params.status);
	if (params.q) search.set("q", params.q);
	if (params.page) search.set("page", String(params.page));
	const query = search.toString();
	return api.get("/events" + (query ? `?${query}` : ""));
};
var getEvent = (id) => api.get(`/events/${id}`);
var createEvent = (values) => api.post("/events", values);
var updateEvent = (id, values) => api.patch(`/events/${id}`, values);
var duplicateEvent = (id) => api.post(`/events/${id}/duplicate`);
var setEventStatus = (id, status) => api.post(`/events/${id}/status`, { status });
var deleteEvent = (id) => api.del(`/events/${id}`);
var saveShift = (eventId, values) => api.post(`/events/${eventId}/shifts`, values);
var updateShift = (shiftId, values) => api.patch(`/shifts/${shiftId}`, values);
var deleteShift = (shiftId) => api.del(`/shifts/${shiftId}`);
var assignShift = (shiftId, values) => api.post(`/shifts/${shiftId}/assignments`, values);
var donationCategories = () => api.get("/donations/categories");
var publicDonationCategories = () => api.get("/public/donation-categories");
var createDonationRequest = (values) => api.post("/public/donation-requests", values);
var listDonationRequests = (params = {}) => {
	const search = new URLSearchParams();
	if (params.status) search.set("status", params.status);
	if (params.q) search.set("q", params.q);
	const query = search.toString();
	return api.get("/donation-requests" + (query ? `?${query}` : ""));
};
var updateDonationRequest = (id, values) => api.patch(`/donation-requests/${id}`, values);
var listDonationTransactions = (params = {}) => {
	const search = new URLSearchParams();
	if (params.from) search.set("from", params.from);
	if (params.to) search.set("to", params.to);
	if (params.category_id) search.set("category_id", params.category_id);
	const query = search.toString();
	return api.get("/donation-transactions" + (query ? `?${query}` : ""));
};
var createDonationTransaction = (values) => api.post("/donation-transactions", values);
var deleteDonationTransaction = (id) => api.del(`/donation-transactions/${id}`);
var saveDonationCategory = (id, values) => id ? api.patch(`/donation-categories/${id}`, values) : api.post("/donation-categories", values);
var deleteDonationCategory = (id) => api.del(`/donation-categories/${id}`);
var listSocialPosts = () => api.get("/social-posts");
var studioMeta = () => api.get("/social/studio");
var createSocialPost = (form) => api.post("/social-posts", form);
var deleteSocialPost = (id) => api.del(`/social-posts/${id}`);
var notifications = () => api.get("/notifications");
var markNotificationsRead = (notificationId) => api.post("/notifications/read", notificationId ? { notification_id: notificationId } : {});
var publicHomepage = () => api.get("/public/homepage");
//#endregion
export { saveDonationCategory as $, hubSetStatus as A, pageHead as B, getEvent as C, hubItems as D, hubInsert as E, listSocialPosts as F, recordSharedExpense as G, publicDonationCategories as H, login as I, reportChoreNeeded as J, reorderSections as K, logout as L, listDonationTransactions as M, listEvents as N, hubRespond as O, listMedia as P, saveChore as Q, markNotificationsRead as R, duplicateEvent as S, hubEdit as T, publicHomepage as U, portalRoles as V, recordPayment as W, resetPassword as X, requestPasswordReset as Y, reviewClaim as Z, deleteMedia as _, updateMediaMeta as _t, changePassword as a, saveSpace as at, deleteSocialPost as b, uploadMedia as bt, createDonationRequest as c, setWashroomAccessBulk as ct, createIssue as d, siteSettings as dt, saveGroup as et, createResident as f, studioMeta as ft, deleteEvent as g, updateIssue as gt, deleteDonationTransaction as h, updateEvent as ht, changeEmail as i, saveSiteSettings as it, listDonationRequests as j, hubResponses as k, createDonationTransaction as l, signup as lt, deleteDonationCategory as m, updateDonationRequest as mt, assignPortalRoles as n, saveShift as nt, choreAdminAction as o, setAdmin as ot, createSocialPost as p, submitClaim as pt, replaceMedia as q, assignShift as r, saveSiteSection as rt, completeChore as s, setEventStatus as st, addAdjustment as t, savePortalRole as tt, createEvent as u, siteContent as ut, deletePortalRole as v, updateResident as vt, hubDelete as w, donationCategories as x, voidExpense as xt, deleteShift as y, updateShift as yt, notifications as z };
