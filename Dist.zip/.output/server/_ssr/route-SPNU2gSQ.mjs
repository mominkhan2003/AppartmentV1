import { L as logout } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { A as House, D as LayoutGrid, E as LogOut, W as Bell, d as Sparkles, i as Wallet, n as Wrench, o as Users, p as Shield, s as UserRound, v as Receipt } from "../_libs/lucide-react.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { b as useNavigate, h as Outlet, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as hubPages, r as hubPaths } from "./hub-U83ja4eR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-SPNU2gSQ.js
var import_jsx_runtime = require_jsx_runtime();
var nav = [
	{
		to: "/dashboard",
		label: "Overview",
		icon: LayoutGrid
	},
	{
		to: "/residents",
		label: "Residents",
		icon: Users
	},
	{
		to: "/expenses",
		label: "Expenses",
		icon: Receipt
	},
	{
		to: "/balance",
		label: "My Balance",
		icon: Wallet
	},
	{
		to: "/cleaning",
		label: "Cleaning",
		icon: Sparkles
	},
	{
		to: "/issues",
		label: "Issues",
		icon: Wrench
	}
];
var adminNav = [
	{
		to: "/admin",
		label: "Admin Portal",
		icon: Shield
	},
	{
		to: "/content",
		label: "Homepage content",
		icon: LayoutGrid
	},
	{
		to: "/media",
		label: "Media library",
		icon: Sparkles
	},
	{
		to: "/events-plan",
		label: "Public events",
		icon: Receipt
	},
	{
		to: "/donations",
		label: "Donations",
		icon: Wallet
	},
	{
		to: "/studio",
		label: "Social posts",
		icon: Wrench
	}
];
function Shell() {
	const { data: me, error } = useMe();
	const qc = useQueryClient();
	const navigate = useNavigate();
	async function signOut() {
		await qc.cancelQueries();
		qc.clear();
		await logout();
		navigate({
			to: "/auth",
			replace: true
		});
	}
	const linkCls = "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground";
	const active = { className: "bg-sidebar-accent text-sidebar-foreground font-medium" };
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col bg-background md:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex shrink-0 flex-col bg-sidebar p-4 text-sidebar-foreground md:sticky md:top-0 md:h-dvh md:w-60 md:overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center gap-2 px-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "h-5 w-5 text-sidebar-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg font-bold",
						children: "FlatMate Hub"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-wrap gap-1 md:flex-col",
					children: nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: n.to,
						className: linkCls,
						activeProps: active,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n.icon, { className: "h-4 w-4" }),
							" ",
							n.label
						]
					}, n.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "my-4",
					open: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer px-3 py-2 text-xs font-semibold uppercase text-sidebar-foreground/60",
						children: "Household extras"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Household extras",
						className: "mt-1 grid grid-cols-2 gap-1 md:grid-cols-1",
						children: hubPaths.map((key) => {
							const item = hubPages[key];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: `/${key}`,
								className: linkCls,
								activeProps: active,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 break-words",
									children: item.title
								})]
							}, key);
						})
					})]
				}),
				me?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "my-4",
					open: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer px-3 py-2 text-xs font-semibold uppercase text-sidebar-foreground/60",
						children: "Administration"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Administration",
						className: "mt-1 grid grid-cols-2 gap-1 md:grid-cols-1",
						children: adminNav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: n.to,
							className: linkCls,
							activeProps: active,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n.icon, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 break-words",
								children: n.label
							})]
						}, n.to))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto border-t border-sidebar-border pt-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-2 font-medium",
							children: me?.resident?.display_name ?? me?.user.email ?? ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-2 text-xs text-sidebar-foreground/60",
							children: me?.isAdmin ? "Admin" : "Resident"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/notifications",
							className: "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground mt-3",
							activeProps: active,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-4 w-4" }), " Notifications"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/account",
							className: linkCls,
							activeProps: active,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "h-4 w-4" }), "My account"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							onClick: signOut,
							className: "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground mt-2 w-full justify-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "min-w-0 flex-1 p-4 md:p-8",
			children: error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-destructive",
				children: error.message
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		})]
	});
}
//#endregion
export { Shell as component };
