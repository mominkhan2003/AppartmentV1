import { r as __toESM } from "../_runtime.mjs";
import { I as login, Y as requestPasswordReset, lt as signup } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { A as House } from "../_libs/lucide-react.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-Cjjp0E3P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const nav = useNavigate();
	const qc = useQueryClient();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function afterAuth() {
		qc.clear();
		await nav({
			to: "/dashboard",
			replace: true
		});
	}
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			if (mode === "in") {
				await login(email, password);
				await afterAuth();
			} else {
				await signup(email, password, name);
				await afterAuth();
			}
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "w-full max-w-sm space-y-4 rounded-2xl border bg-card p-8 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-bold",
						children: "FlatMate Hub"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: mode === "in" ? "Welcome back" : "Join your flat"
				}),
				mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "name",
						children: "Your name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "email",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "pw",
						children: "Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "pw",
						type: "password",
						minLength: 8,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					disabled: busy,
					children: mode === "in" ? "Sign in" : "Create account"
				}),
				mode === "in" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "link",
					className: "w-full",
					disabled: busy,
					onClick: async () => {
						if (!email) {
							toast.error("Enter your login email first.");
							return;
						}
						setBusy(true);
						try {
							const result = await requestPasswordReset(email);
							if (result.dev_token) toast.success("Password reset link: " + window.location.origin + "/reset-password?token=" + result.dev_token);
							else toast.success(result.message ?? "If an account exists, a password reset link has been sent.");
						} catch (err) {
							toast.error(err.message);
						} finally {
							setBusy(false);
						}
					},
					children: "Forgot password?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "link",
					className: "w-full text-sm text-muted-foreground",
					onClick: () => setMode(mode === "in" ? "up" : "in"),
					children: mode === "in" ? "New here? Create an account" : "Already have an account? Sign in"
				}),
				mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Password: at least 8 characters. The first person to sign up becomes the flat admin. If the admin added you with your email, your account links automatically."
				})
			]
		})
	});
}
//#endregion
export { AuthPage as component };
