import { r as __toESM } from "../_runtime.mjs";
import { r as mediaUrl } from "./api-Bz4c_dXI.mjs";
import { H as publicDonationCategories, U as publicHomepage, c as createDonationRequest } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { A as House, d as Sparkles, n as Wrench, v as Receipt } from "../_libs/lucide-react.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DEh_M-a5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The design source of truth — rendered verbatim whenever the CMS has no override. */
var FALLBACK = {
	hero: {
		heading: "Seven people, one flat, zero spreadsheets.",
		subheading: "Everything your shared flat needs: who owes what, whose turn it is to clean, and what needs fixing.",
		cta_label: "Sign in",
		cta_href: "/auth"
	},
	features: [
		{
			icon: "receipt",
			t: "Fair expenses",
			d: "Split by group or custom shares, claims reviewed by the admin."
		},
		{
			icon: "sparkles",
			t: "Cleaning rota",
			d: "Duties rotate automatically, with photo proof."
		},
		{
			icon: "wrench",
			t: "Issues",
			d: "Report a broken tap, follow it until resolved."
		},
		{
			icon: "home",
			t: "Floor plan",
			d: "See every room and washroom in 2D or 3D."
		}
	]
};
var ICONS = {
	receipt: Receipt,
	sparkles: Sparkles,
	wrench: Wrench,
	home: House
};
var iconFor = (name) => name && ICONS[name] || House;
function sectionCopy(s, lang) {
	const en = s.translations.en ?? null;
	const de = s.translations.de ?? null;
	const rows = lang === "de" ? [de, en] : [en, de];
	for (const row of rows) {
		if (!row) continue;
		if ((row.heading ?? "") !== "" || (row.body ?? "") !== "") return {
			heading: row.heading ?? "",
			subheading: row.subheading ?? "",
			body: row.body ?? ""
		};
	}
	return null;
}
function Index() {
	const [lang, setLang] = (0, import_react.useState)("en");
	const hub = useQuery({
		queryKey: ["public-homepage"],
		queryFn: publicHomepage,
		staleTime: 6e4,
		retry: 1
	});
	const data = hub.data;
	const sections = data?.sections ?? [];
	const hero = sections.find((s) => s.kind === "hero" && s.area === "home");
	const features = sections.filter((s) => s.kind === "feature").sort((a, b) => a.sort - b.sort);
	const hasGerman = sections.some((s) => (s.translations.de?.heading ?? s.translations.de?.subheading ?? s.translations.de?.body ?? "") !== "");
	const heroCopy = hero ? sectionCopy(hero, lang) : null;
	const heading = heroCopy?.heading || FALLBACK.hero.heading;
	const subheading = heroCopy?.subheading || heroCopy?.body || FALLBACK.hero.subheading;
	const ctaLabel = hero?.cta_label || FALLBACK.hero.cta_label;
	const ctaHref = hero?.cta_href || FALLBACK.hero.cta_href;
	const heroMedia = hero?.media_id ? mediaUrl(hero.media_id) : null;
	const events = data?.events ?? [];
	const impact = data?.impact ?? null;
	const settings = data?.settings ?? {};
	const siteName = typeof settings.site_name === "string" && settings.site_name ? settings.site_name : "FlatMate Hub";
	const donationsEnabled = impact?.enabled !== false && settings.donations_public === true;
	const showLocaleToggle = hasGerman && hub.isSuccess;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-6 py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "h-6 w-6" }),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-lg font-bold",
								children: siteName
							})
						]
					}), showLocaleToggle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Switch language",
						onClick: () => setLang(lang === "en" ? "de" : "en"),
						className: "rounded-md border px-2 py-1 text-sm hover:bg-accent",
						children: lang === "en" ? "Deutsch" : "English"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-10 max-w-2xl text-5xl font-bold leading-tight",
					children: heading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg text-muted-foreground",
					children: subheading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					size: "lg",
					className: "mt-8",
					children: ctaHref === "/auth" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						children: ctaLabel
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: ctaHref,
						children: ctaLabel
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: (features.length ? features.map((s) => {
						const copy = sectionCopy(s, lang);
						return {
							icon: s.icon ?? "home",
							t: copy?.heading ?? "",
							d: copy?.body || copy?.subheading || ""
						};
					}) : FALLBACK.features).map((i) => {
						const Icon = iconFor(i.icon);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border bg-card p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-accent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-semibold",
									children: i.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: i.d
								})
							]
						}, i.t);
					})
				}),
				heroMedia && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: heroMedia,
					alt: "",
					className: "mt-12 w-full rounded-xl border object-cover"
				}),
				events.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventsStrip, {
					events,
					lang
				}),
				donationsEnabled && impact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Donations, {
					impact,
					settings,
					lang
				})
			]
		})
	});
}
function EventsStrip({ events, lang }) {
	const byId = /* @__PURE__ */ new Map();
	for (const e of events) {
		const existing = byId.get(e.id);
		const preferred = lang === "de" ? e.locale === "de" : e.locale === "en";
		if (!existing || preferred && existing.locale !== lang) byId.set(e.id, e);
	}
	const shown = [...byId.values()].slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-bold",
			children: lang === "de" ? "Nächste Termine" : "Upcoming events"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: shown.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-accent",
						children: (/* @__PURE__ */ new Date(e.starts_at + "Z")).toLocaleString(lang === "de" ? "de-AT" : "en-IE", {
							dateStyle: "medium",
							timeStyle: "short"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 font-semibold",
						children: e.title ?? (lang === "de" ? "Treffen" : "Meet-up")
					}),
					(e.meeting_point || e.address) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: e.meeting_point || e.address
					})
				]
			}, e.id))
		})]
	});
}
function Donations({ impact, settings, lang }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const eurFormat = (cents) => new Intl.NumberFormat("de-AT", {
		style: "currency",
		currency: "EUR"
	}).format((cents ?? 0) / 100);
	const instructions = typeof settings.donations_instructions === "string" ? settings.donations_instructions : "";
	const account = typeof settings.donations_account === "string" ? settings.donations_account : "";
	const categories = useQuery({
		queryKey: ["public-donation-categories"],
		enabled: open,
		staleTime: 3e5,
		queryFn: publicDonationCategories
	});
	const total = impact.total_amount_cents ?? 0;
	const goal = impact.goal_cents ?? null;
	async function submit(e) {
		e.preventDefault();
		const form = new FormData(e.currentTarget);
		const amountRaw = String(form.get("amount") ?? "").trim();
		try {
			await createDonationRequest({
				contact_name: String(form.get("contact_name") ?? ""),
				contact_email: String(form.get("contact_email") ?? ""),
				contact_phone: String(form.get("contact_phone") ?? "") || null,
				amount_cents: amountRaw ? Math.round(parseFloat(amountRaw.replace(",", ".")) * 100) : null,
				category_id: String(form.get("category_id") ?? "") || null,
				message: String(form.get("message") ?? "") || null
			});
			toast.success(lang === "de" ? "Danke! Wir melden uns bei dir." : "Thank you! We will get back to you.");
			setOpen(false);
		} catch (error) {
			toast.error(error.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-16 rounded-xl border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-bold",
				children: lang === "de" ? "Unterstützen" : "Support the flat"
			}),
			instructions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl whitespace-pre-line text-sm text-muted-foreground",
				children: instructions
			}),
			account && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 break-words text-sm text-muted-foreground",
				children: account
			}),
			total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					lang === "de" ? "Bisher gesammelt" : "Raised so far",
					": ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: eurFormat(total) }),
					impact.this_year_amount_cents ? ` (${lang === "de" ? "heuer" : "this year"}: ${eurFormat(impact.this_year_amount_cents)})` : ""
				]
			}),
			goal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("progress", {
				className: "mt-3 h-2 w-full accent-primary",
				value: Math.min(total, goal),
				max: goal
			}) : null,
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-5 grid max-w-md gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "contact_name",
						placeholder: lang === "de" ? "Name" : "Name",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "contact_email",
						type: "email",
						placeholder: "Email",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "contact_phone",
						placeholder: lang === "de" ? "Telefon (optional)" : "Phone (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "amount",
						type: "number",
						min: "1",
						step: "0.01",
						placeholder: lang === "de" ? "Betrag in EUR (optional)" : "Amount in EUR (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "category_id",
						className: "h-9 rounded-md border bg-background px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: lang === "de" ? "Zweck (optional)" : "Purpose (optional)"
						}), (categories.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						name: "message",
						rows: 3,
						maxLength: 2e3,
						placeholder: lang === "de" ? "Nachricht" : "Message",
						className: "w-full rounded-md border bg-background p-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: lang === "de" ? "Anfrage senden" : "Send request"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setOpen(false),
							children: lang === "de" ? "Abbrechen" : "Cancel"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-4",
				onClick: () => setOpen(true),
				children: lang === "de" ? "Spendenanfrage" : "Make a donation request"
			})
		]
	});
}
//#endregion
export { Index as component };
