import { r as __toESM } from "../_runtime.mjs";
import { V as portalRoles, at as saveSpace, ct as setWashroomAccessBulk, et as saveGroup, n as assignPortalRoles, ot as setAdmin, tt as savePortalRole, v as deletePortalRole } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { m as ShieldCheck, u as Trash2, x as Pencil, y as Plus } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as useRefresh, b as useWashroomAccess, g as useMe, p as useGroups, s as useAudit, v as useResidents, y as useSpaces } from "./flat-prlcA8Ar.mjs";
import { n as portalPermissions, t as canManage } from "./portal-permissions-Yq28ENt1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-C48GCxJI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RoleManager() {
	const { data: me } = useMe();
	const { data: residents = [] } = useResidents();
	const refresh = useRefresh();
	const bundle = useQuery({
		queryKey: ["portal-roles"],
		queryFn: portalRoles
	});
	const roles = bundle.data?.roles ?? [];
	const members = bundle.data?.members ?? [];
	const admins = bundle.data?.admins ?? [];
	const roleEditor = (role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: role ? "Edit role" : "Create role",
		trigger: role ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "icon",
			variant: "outline",
			"aria-label": "Edit role " + role.name,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Create role"] }),
		onSave: async (d) => {
			await savePortalRole(role?.id ?? null, {
				name: text(d, "name"),
				description: text(d, "description"),
				permissions: d.getAll("permissions").map(String)
			});
			await refresh();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Role name",
				name: "name",
				value: role?.name,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Description",
				name: "description",
				value: role?.description ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-3 text-sm font-semibold",
					children: "Permissions"
				}), portalPermissions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						name: "permissions",
						value: p.id,
						defaultChecked: role?.permissions.includes(p.id),
						className: "mt-1"
					}), p.name]
				}, p.id))]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-semibold",
				children: "Custom roles"
			}), roleEditor()]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: bundle }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold break-words",
							children: role.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [roleEditor(role), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
								title: "Delete " + role.name,
								destructive: true,
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "outline",
									"aria-label": "Delete role " + role.name,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
								}),
								onSave: async () => {
									await deletePortalRole(role.id);
									await refresh();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: "Remove this role from all assigned accounts?"
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground break-words",
						children: role.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 text-sm",
						children: role.permissions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: portalPermissions.find((x) => x.id === p)?.name }, p))
					}),
					!role.permissions.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: "No additional permissions"
					})
				]
			}, role.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 mb-4 text-xl font-semibold",
			children: "Account access"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y border-y",
			children: residents.filter((r) => r.user_id).map((r) => {
				const isAdmin = admins.includes(r.id);
				const assigned = members.filter((m) => m.user_id === r.user_id).map((m) => m.role_id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold break-words",
								children: [r.display_name, r.user_id === me?.user.id && " (you)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground break-all",
								children: r.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: [isAdmin ? "Administrator · Full access" : "Resident", assigned.length ? " · " + roles.filter((x) => assigned.includes(x.id)).map((x) => x.name).join(", ") : ""]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
							title: "Roles for " + r.display_name,
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								disabled: bundle.isPending || !!bundle.error,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}), "Assign roles"]
							}),
							onSave: async (d) => {
								await assignPortalRoles(r.id, d.getAll("roles").map(String));
								await refresh();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "grid gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "mb-3 text-sm font-semibold",
									children: "Custom roles"
								}), roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										name: "roles",
										value: role.id,
										defaultChecked: assigned.includes(role.id)
									}), role.name]
								}, role.id))]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
							title: isAdmin ? "Remove administrator" : "Grant administrator",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								disabled: r.user_id === me?.user.id || bundle.isPending || !!bundle.error,
								children: isAdmin ? "Remove admin" : "Make admin"
							}),
							onSave: async () => {
								await setAdmin(r.id, !isAdmin);
								await refresh();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									isAdmin ? "Remove full administrator access from" : "Give full administrator access to",
									" ",
									r.display_name,
									"?"
								]
							})
						})]
					})]
				}, r.id);
			})
		})
	] });
}
function Admin() {
	const me = useMe();
	const [tab, setTab] = (0, import_react.useState)("household");
	const household = !!me.data && canManage(me.data.isAdmin, me.data.permissions, "household.manage");
	const audit = !!me.data && canManage(me.data.isAdmin, me.data.permissions, "audit.read");
	const { data: residents = [] } = useResidents();
	const { data: spaces = [] } = useSpaces();
	const { data: groups = [] } = useGroups();
	const { data: access = [] } = useWashroomAccess();
	const refresh = useRefresh();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Admin Portal",
			sub: me.data?.isAdmin ? "Administrator · Full household access" : "Delegated household access"
		}),
		me.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex flex-wrap gap-2",
			children: [
				{
					id: "household",
					name: "Household",
					allowed: household
				},
				{
					id: "roles",
					name: "Roles & access",
					allowed: me.data.isAdmin
				},
				{
					id: "audit",
					name: "Audit history",
					allowed: audit
				}
			].filter((t) => t.allowed).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: tab === t.id ? "default" : "outline",
				onClick: () => setTab(t.id),
				children: t.name
			}, t.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: me }),
		me.data && !household && !audit && !me.data.isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "You do not have access to portal settings." }) : me.data && (household || audit || me.data.isAdmin) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			tab === "household" && household && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-semibold",
					children: "Household groups"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
					title: "Add group",
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add group"] }),
					onSave: async (d) => {
						await saveGroup(void 0, {
							name: text(d, "name"),
							description: text(d, "description") || null,
							members: d.getAll("members").map(String)
						});
						await refresh();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Name",
							name: "name",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Description",
							name: "description"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-sm",
								children: "Members"
							}), residents.filter((r) => r.active).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									name: "members",
									value: r.id
								}), r.display_name]
							}, r.id))]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y border-y",
				children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold",
						children: g.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: residents.filter((r) => g.members.includes(r.id)).map((r) => r.display_name).join(", ") || "No members"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
						title: "Edit group",
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							"aria-label": "Edit " + g.name,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
						}),
						onSave: async (d) => {
							await saveGroup(g.id, {
								name: text(d, "name"),
								description: text(d, "description") || null,
								members: d.getAll("members").map(String)
							});
							await refresh();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Name",
								name: "name",
								value: g.name,
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
								label: "Description",
								name: "description",
								value: g.description ?? ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "mb-2 text-sm",
									children: "Members"
								}), residents.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										name: "members",
										type: "checkbox",
										value: r.id,
										defaultChecked: g.members.includes(r.id)
									}), r.display_name]
								}, r.id))]
							})
						]
					})]
				}, g.id))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-xl font-semibold",
					children: "Rooms and washroom access"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
					children: spaces.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: s.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs capitalize text-muted-foreground",
									children: [s.kind, s.kind === "bedroom" ? " · Capacity " + s.capacity : ""]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
									title: "Edit " + s.name,
									trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "icon",
										"aria-label": "Edit " + s.name,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
									}),
									onSave: async (d) => {
										const capacity = Number(text(d, "capacity"));
										if (!Number.isInteger(capacity) || capacity < 0) throw new Error("Capacity must be a whole non-negative number");
										await saveSpace(s.id, {
											name: text(d, "name"),
											capacity,
											notes: text(d, "notes") || null
										});
										if (s.kind === "bedroom") await setWashroomAccessBulk(s.id, d.getAll("washrooms").map(String));
										await refresh();
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
											label: "Name",
											name: "name",
											value: s.name,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
											label: "Capacity",
											name: "capacity",
											type: "number",
											value: s.capacity,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, { value: s.notes ?? "" }),
										s.kind === "bedroom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
											className: "grid gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
												className: "mb-2 text-sm",
												children: "Washroom access"
											}), spaces.filter((w) => w.kind === "washroom").map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex gap-2 text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													name: "washrooms",
													value: w.id,
													defaultChecked: access.some((a) => a.bedroom_id === s.id && a.washroom_id === w.id)
												}), w.name]
											}, w.id))]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground break-words",
								children: s.notes
							}),
							s.kind === "bedroom" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs",
								children: access.filter((a) => a.bedroom_id === s.id).map((a) => spaces.find((w) => w.id === a.washroom_id)?.name).join(" · ") || "No washroom assigned"
							})
						]
					}, s.id))
				})]
			})] }),
			tab === "roles" && me.data.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleManager, {}),
			tab === "audit" && audit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Audit, {})
		] })
	] });
}
function Audit() {
	const query = useAudit();
	const { data: residents = [] } = useResidents();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-4 text-xl font-semibold",
				children: "Audit history"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y border-y",
				children: query.data?.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium capitalize",
							children: [
								a.action.replaceAll("_", " "),
								" · ",
								a.entity
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								new Date(a.created_at).toLocaleString(),
								" ·",
								" ",
								residents.find((r) => r.user_id === a.actor_id)?.display_name ?? "System"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs text-muted-foreground",
							children: JSON.stringify(a.details)
						})
					]
				}, a.id))
			}),
			!query.data?.length && !query.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No recorded admin actions yet." })
		]
	});
}
//#endregion
export { Admin as component };
