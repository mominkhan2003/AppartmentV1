//#region node_modules/.nitro/vite/services/ssr/assets/api-Bz4c_dXI.js
/**
* Thin fetch client for the self-managed PHP/MySQL backend (backend/api).
* Same-origin cookies carry the session (HttpOnly), so no tokens live in JS.
* Every unsafe call sends X-Requested-With as the CSRF fallback header; browsers
* also send Origin on same-origin POSTs, both accepted by backend/src/Csrf.php.
*/
var ApiError = class extends Error {
	status;
	constructor(message, status = 0) {
		super(message);
		this.name = "ApiError";
		this.status = status;
	}
};
var BASE = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "omqgatbovglkffggxczx",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_pckdOQnnF-D0U0IUIywzXg_EIJzBgKJ",
	"VITE_SUPABASE_URL": "https://omqgatbovglkffggxczx.supabase.co"
}["VITE_API_BASE"] ?? "/api";
async function unwrap(res) {
	let payload = null;
	try {
		payload = await res.json();
	} catch {}
	if (!res.ok) throw new ApiError(payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string" ? payload.error : `Request failed (${res.status})`, res.status);
	return payload;
}
async function request(method, path, body) {
	const headers = { Accept: "application/json" };
	const init = {
		method,
		headers,
		credentials: "same-origin"
	};
	if (body !== void 0) if (body instanceof FormData) init.body = body;
	else {
		headers["Content-Type"] = "application/json";
		init.body = JSON.stringify(body);
	}
	if (method !== "GET" && method !== "HEAD") headers["X-Requested-With"] = "XMLHttpRequest";
	return await unwrap(await fetch(BASE + path, init));
}
var api = {
	get: (path) => request("GET", path),
	post: (path, body) => request("POST", path, body),
	patch: (path, body) => request("PATCH", path, body),
	put: (path, body) => request("PUT", path, body),
	del: (path) => request("DELETE", path)
};
/** Media files are never addressable by raw disk path; they stream through the API. */
var mediaUrl = (mediaId) => `${BASE}/media/${mediaId}/file`;
function openMedia(mediaId) {
	if (mediaId) window.open(mediaUrl(mediaId), "_blank", "noopener");
}
//#endregion
export { openMedia as i, api as n, mediaUrl as r, ApiError as t };
