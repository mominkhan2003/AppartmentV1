import { a as changePassword, i as changeEmail, vt as updateResident } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { O as KeyRound, T as Mail, s as UserRound } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, r as Editor } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, g as useMe } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-C_T-q1Vw.js
var import_jsx_runtime = require_jsx_runtime();
function Account() {
	const query = useMe();
	const me = query.data;
	const refresh = useRefresh();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "My account" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
			me && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y border-y",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-wrap items-center justify-between gap-4 py-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "flex items-center gap-2 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "h-4 w-4" }), "Name"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm",
								children: me.resident?.display_name ?? "Not set"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: me.isAdmin ? "Administrator · Full access" : "Resident"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
							title: "Change name",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								disabled: !me.resident,
								children: "Change name"
							}),
							onSave: async (d) => {
								if (!me.resident) throw new Error("Resident account not found");
								await updateResident(me.resident.id, { display_name: text(d, "name") });
								await refresh();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Name",
								name: "name",
								value: me.resident?.display_name,
								required: true
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-wrap items-center justify-between gap-4 py-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "flex items-center gap-2 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), "Login email"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 break-all text-sm",
								children: me.user.email
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
							title: "Change login email",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								children: "Change email"
							}),
							onSave: async (d) => {
								if (text(d, "current_password") === "") throw new Error("Enter your current password to confirm the change");
								await changeEmail(text(d, "email"), text(d, "current_password"));
								toast.success("Email updated. Use the new address the next time you sign in.");
								await refresh();
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "New email",
								type: "email",
								name: "email",
								required: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Current password (confirm)",
								name: "current_password",
								type: "password",
								required: true
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-wrap items-center justify-between gap-4 py-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "flex items-center gap-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-4 w-4" }), "Password"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
							title: "Change password",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								children: "Change password"
							}),
							onSave: async (d) => {
								const password = text(d, "password");
								if (password.length < 8) throw new Error("Use at least 8 characters");
								if (password !== text(d, "confirm")) throw new Error("Passwords do not match");
								await changePassword(text(d, "current"), password);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
									label: "Current password",
									name: "current",
									type: "password",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
									label: "New password",
									name: "password",
									type: "password",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
									label: "Confirm password",
									name: "confirm",
									type: "password",
									required: true
								})
							]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Account as component };
