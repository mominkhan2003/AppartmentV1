import { r as __toESM } from "../_runtime.mjs";
import { d as createIssue, gt as updateIssue } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { k as Image, x as Pencil, y as Plus } from "../_libs/lucide-react.mjs";
import { a as FileField, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice, u as upload } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, g as useMe, i as openFile, m as useIssues, v as useResidents, y as useSpaces } from "./flat-prlcA8Ar.mjs";
import { t as canManage } from "./portal-permissions-Yq28ENt1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/issues-Bp3qDquA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Issues() {
	const query = useIssues();
	const { data: spaces = [] } = useSpaces();
	const { data: residents = [] } = useResidents();
	const { data: me } = useMe();
	const refresh = useRefresh();
	const [filter, setFilter] = (0, import_react.useState)("open");
	const issues = (query.data ?? []).filter((i) => filter === "all" || (filter === "open" ? i.status !== "resolved" : i.status === "resolved"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Issues",
			sub: "Everything that needs attention",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
				title: "Report an issue",
				trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Report issue"] }),
				onSave: async (d) => {
					const file = upload(d);
					await createIssue(d, {
						reporterResidentId: me?.resident?.id ?? null,
						photo: file
					});
					await refresh();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Space",
						name: "space",
						options: spaces.map((s) => ({
							id: s.id,
							name: s.name
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Category",
						name: "category",
						value: "maintenance",
						options: [
							"maintenance",
							"cleanliness",
							"damage",
							"other"
						].map((s) => ({
							id: s,
							name: s
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
						label: "Description",
						name: "description",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileField, {})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex gap-2",
			children: [
				"open",
				"resolved",
				"all"
			].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: filter === s ? "default" : "outline",
				onClick: () => setFilter(s),
				className: "capitalize",
				children: s
			}, s))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: issues.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: i.status }), me && canManage(me.isAdmin, me.permissions, "issues.manage") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
							title: "Update issue",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "outline",
								"aria-label": "Update issue",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
							}),
							onSave: async (d) => {
								const status = text(d, "status");
								await updateIssue(i.id, {
									status,
									assigned_resident_id: text(d, "assigned") || null,
									admin_response: text(d, "response") || null,
									resolution_notes: text(d, "resolution") || null
								});
								await refresh();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									label: "Status",
									name: "status",
									value: i.status,
									required: true,
									options: [
										"open",
										"acknowledged",
										"in_progress",
										"resolved"
									].map((s) => ({
										id: s,
										name: s.replaceAll("_", " ")
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									label: "Assigned to",
									name: "assigned",
									value: i.assigned_resident_id ?? "",
									options: residents.filter((r) => r.active).map((r) => ({
										id: r.id,
										name: r.display_name
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Admin response",
									name: "response",
									value: i.admin_response ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Resolution",
									name: "resolution",
									value: i.resolution_notes ?? ""
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 whitespace-pre-wrap break-words font-medium",
						children: i.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							spaces.find((s) => s.id === i.space_id)?.name ?? "Whole flat",
							" · ",
							i.category,
							" ·",
							" ",
							new Date(i.created_at).toLocaleDateString()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							"Reported by",
							" ",
							residents.find((r) => r.id === i.reporter_resident_id)?.display_name ?? "Resident",
							i.assigned_resident_id && " · Assigned to " + residents.find((r) => r.id === i.assigned_resident_id)?.display_name
						]
					}),
					i.admin_response && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 border-t pt-3 text-sm break-words",
						children: i.admin_response
					}),
					i.resolution_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-success break-words",
						children: i.resolution_notes
					}),
					i.photo_media_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "link",
						className: "mt-2 px-0",
						onClick: () => openFile("photos", i.photo_media_id ?? ""),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {}), "View photo"]
					})
				]
			}, i.id))
		}),
		!query.isPending && !issues.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [
			"No ",
			filter === "all" ? "" : filter,
			" issues."
		] })
	] });
}
//#endregion
export { Issues as component };
