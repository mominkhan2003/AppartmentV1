import { r as __toESM } from "../_runtime.mjs";
import { A as hubSetStatus, D as hubItems, E as hubInsert, O as hubRespond, T as hubEdit, k as hubResponses, w as hubDelete } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { B as CheckCheck, F as ExternalLink, K as ArrowRight, R as Clock, T as Mail, b as Phone, g as Search, l as Undo2, u as Trash2, w as MapPin, x as Pencil, y as Plus, z as Check } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice } from "./Forms-Cipd7J0Q.mjs";
import { a as run, n as PageHeader } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe, v as useResidents } from "./flat-prlcA8Ar.mjs";
import { a as safeDocumentUrl, i as pollOptions, n as hubPages, o as valueOf, t as formPayload } from "./hub-U83ja4eR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/HubPage-ByHu0c7G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HubPage({ kind }) {
	const config = hubPages[kind];
	const { data: me } = useMe();
	const { data: residents = [] } = useResidents();
	const qc = useQueryClient();
	const [search, setSearch] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("open");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const query = useQuery({
		queryKey: ["hub", kind],
		queryFn: () => hubItems(kind)
	});
	const responses = useQuery({
		queryKey: ["hub-responses", kind],
		queryFn: () => hubResponses(kind)
	});
	async function refresh() {
		await Promise.all([qc.invalidateQueries({ queryKey: ["hub", kind] }), qc.invalidateQueries({ queryKey: ["hub-responses", kind] })]);
	}
	async function action(id, fn, message) {
		setBusy(id);
		await run(async () => {
			await fn();
			await refresh();
		}, message);
		setBusy(null);
	}
	const items = query.data ?? [];
	const visible = items.filter((item) => (filter === "all" || item.status === filter) && `${item.title} ${item.details} ${JSON.stringify(item.payload)}`.toLowerCase().includes(search.toLowerCase()));
	if (kind === "events" || kind === "bookings") visible.sort((a, b) => valueOf(a, "start").localeCompare(valueOf(b, "start")));
	const canCreate = !!me && (!config.adminOnly || me.isAdmin);
	const name = (uid) => residents.find((r) => r.user_id === uid)?.display_name ?? "Household member";
	const respond = (item, value) => action(item.id, () => hubRespond(item.id, value), value === "release" ? "Returned" : "Response saved");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: config.title,
				action: canCreate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
					title: `Add ${config.singular}`,
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }),
						"Add ",
						config.singular
					] }),
					onSave: async (data) => {
						const title = text(data, "title");
						if (!title || title.length > 160) throw new Error("Title must be between 1 and 160 characters");
						await hubInsert({
							kind,
							title,
							details: text(data, "details"),
							payload: formPayload(kind, data)
						});
						await refresh();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: kind === "polls" ? "Question" : "Title",
							name: "title",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Details",
							name: "details"
						}),
						config.fields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: field.label,
							name: field.key,
							type: field.type,
							required: field.type === "datetime-local" || field.key === "resource" || field.key === "url"
						}, field.key)),
						kind === "polls" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Options (one per line)",
							name: "options",
							required: true
						}),
						kind === "lost-found" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							label: "Report type",
							name: "reportType",
							value: "found",
							options: [{
								id: "lost",
								name: "Lost"
							}, {
								id: "found",
								name: "Found"
							}]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-wrap items-center justify-between gap-4 border-y py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(config.icon, { className: "h-5 w-5 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: items.filter((i) => i.status === "open").length }), " active"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [items.filter((i) => i.status === "done").length, " closed"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full flex-wrap items-center gap-2 sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-w-0 flex-1 sm:w-56",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": `Search ${config.title}`,
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: "Search…",
							className: "pl-9"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1",
						"aria-label": "Filter items",
						children: [
							"open",
							"done",
							"all"
						].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: filter === value ? "secondary" : "ghost",
							size: "sm",
							onClick: () => setFilter(value),
							children: value === "open" ? "Active" : value === "done" ? "Closed" : "All"
						}, value))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: responses }),
			!query.isPending && !query.error && !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-16 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(config.icon, { className: "mx-auto mb-4 h-10 w-10 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: search ? "No matches" : filter === "done" ? "Nothing closed yet" : `No ${config.title.toLowerCase()} yet`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: kind === "shopping" ? "grid gap-3" : "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
				children: visible.map((item) => {
					const itemResponses = (responses.data ?? []).filter((r) => r.item_id === item.id);
					const mine = itemResponses.find((r) => r.user_id === me?.user.id);
					const owner = me?.isAdmin || item.created_by === me?.user.id;
					const url = safeDocumentUrl(valueOf(item, "url"));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex min-w-0 flex-col rounded-lg border bg-card p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "break-words text-lg font-semibold",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: [
											name(item.created_by),
											" · ",
											new Date(item.created_at).toLocaleDateString()
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.status === "done" ? "closed" : "active" })]
							}),
							item.details && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 whitespace-pre-wrap break-words text-sm text-muted-foreground",
								children: item.details
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-3 space-y-2 text-sm",
								children: config.fields.filter((f) => f.key !== "url" && f.key !== "phone" && f.key !== "email").map((f) => valueOf(item, f.key) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "shrink-0 text-muted-foreground",
										children: f.type === "datetime-local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" }) : f.key === "location" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }) : `${f.label}:`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "min-w-0 break-words",
										children: f.type === "datetime-local" ? new Date(valueOf(item, f.key)).toLocaleString() : valueOf(item, f.key)
									})]
								}, f.key))
							}),
							kind === "lost-found" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm font-medium capitalize",
								children: valueOf(item, "reportType") || "found"
							}),
							kind === "documents" && url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: url,
									target: "_blank",
									rel: "noopener noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" }), "Open document"]
								})
							}),
							kind === "contacts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [
									valueOf(item, "phone") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: `tel:${valueOf(item, "phone").replace(/[^+\d]/g, "")}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }), "Call"]
										})
									}),
									valueOf(item, "email") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: `mailto:${valueOf(item, "email")}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), "Email"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "w-full break-words text-sm text-muted-foreground",
										children: [
											valueOf(item, "phone"),
											" ",
											valueOf(item, "email")
										]
									})
								]
							}),
							kind === "polls" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 space-y-3",
								children: [pollOptions(item).map((option) => {
									const count = itemResponses.filter((r) => r.value === option).length;
									const percent = itemResponses.length ? Math.round(count / itemResponses.length * 100) : 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: mine?.value === option ? "secondary" : "outline",
										className: "h-auto min-h-9 w-full justify-between whitespace-normal text-left",
										disabled: busy === item.id || item.status === "done",
										onClick: () => respond(item, option),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 break-words",
											children: [mine?.value === option && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mr-1 inline h-4 w-4" }), option]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-2 shrink-0 text-xs",
											children: [
												count,
												" · ",
												percent,
												"%"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("progress", {
										value: count,
										max: Math.max(itemResponses.length, 1),
										className: "mt-1 h-1 w-full accent-primary"
									})] }, option);
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [itemResponses.length, " votes"]
								})]
							}),
							kind === "events" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: [
											"going",
											"maybe",
											"not-going"
										].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: mine?.value === value ? "secondary" : "outline",
											disabled: busy === item.id || item.status === "done",
											onClick: () => respond(item, value),
											children: value === "not-going" ? "Can't go" : value === "going" ? "Going" : "Maybe"
										}, value))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-xs text-muted-foreground",
										children: [
											itemResponses.filter((r) => r.value === "going").length,
											" going · ",
											itemResponses.filter((r) => r.value === "maybe").length,
											" maybe"
										]
									}),
									itemResponses.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 break-words text-xs text-muted-foreground",
										children: itemResponses.filter((r) => r.value === "going").map((r) => name(r.user_id)).join(", ")
									})
								]
							}),
							(kind === "notices" || kind === "rules") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: mine ? "secondary" : "outline",
									disabled: !!mine || busy === item.id || item.status === "done",
									onClick: () => respond(item, "acknowledged"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-4 w-4" }), mine ? "Acknowledged" : "Acknowledge"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: [itemResponses.length, " acknowledged"]
								})]
							}),
							(kind === "inventory" || kind === "lost-found") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: itemResponses[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-2 text-sm",
									children: [
										kind === "inventory" ? "Borrowed" : "Claimed",
										" by ",
										name(itemResponses[0].user_id)
									]
								}), (mine || me?.isAdmin) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									disabled: busy === item.id,
									onClick: () => respond(item, "release"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-4 w-4" }), kind === "inventory" ? "Return item" : "Release claim"]
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									disabled: busy === item.id || item.status === "done",
									onClick: () => respond(item, "claimed"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" }), kind === "inventory" ? "Borrow item" : "Claim item"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex flex-wrap items-center gap-2 border-t pt-3",
								children: [
									owner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
										title: `Edit ${config.singular}`,
										trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											"aria-label": `Edit ${item.title}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
										}),
										onSave: async (data) => {
											await hubEdit(item.id, {
												title: text(data, "title"),
												details: text(data, "details"),
												payload: formPayload(kind, data)
											});
											await refresh();
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
												label: kind === "polls" ? "Question" : "Title",
												name: "title",
												value: item.title,
												required: true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
												label: "Details",
												name: "details",
												value: item.details
											}),
											config.fields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
												label: field.label,
												name: field.key,
												type: field.type,
												value: field.type === "datetime-local" && valueOf(item, field.key) ? localDate(valueOf(item, field.key)) : valueOf(item, field.key),
												required: field.type === "datetime-local" || field.key === "resource" || field.key === "url"
											}, field.key)),
											kind === "polls" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
												label: "Options (one per line)",
												name: "options",
												value: pollOptions(item).join("\n"),
												required: true
											}),
											kind === "lost-found" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
												label: "Report type",
												name: "reportType",
												value: valueOf(item, "reportType") || "found",
												options: [{
													id: "lost",
													name: "Lost"
												}, {
													id: "found",
													name: "Found"
												}]
											})
										]
									}),
									(owner || kind === "shopping") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "ghost",
										disabled: busy === item.id,
										onClick: () => action(item.id, () => hubSetStatus(item.id, item.status === "open" ? "done" : "open"), "Updated"),
										children: [item.status === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), item.status === "done" ? "Reopen" : kind === "shopping" ? "Purchased" : "Close"]
									}),
									owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
										title: `Delete ${config.singular}`,
										destructive: true,
										trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											"aria-label": `Delete ${item.title}`,
											className: "ml-auto text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
										}),
										onSave: async () => {
											await hubDelete(item.id);
											await refresh();
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "break-words text-sm",
											children: [
												"Delete “",
												item.title,
												"” and all its responses?"
											]
										})
									})
								]
							})
						]
					}, item.id);
				})
			})
		]
	});
}
function localDate(value) {
	const date = new Date(value);
	return (/* @__PURE__ */ new Date(date.getTime() - date.getTimezoneOffset() * 6e4)).toISOString().slice(0, 16);
}
//#endregion
export { HubPage as t };
