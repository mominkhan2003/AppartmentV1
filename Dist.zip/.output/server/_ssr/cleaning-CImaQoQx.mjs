import { r as __toESM } from "../_runtime.mjs";
import { J as reportChoreNeeded, Q as saveChore, o as choreAdminAction, s as completeChore } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { k as Image, x as Pencil, y as Plus, z as Check } from "../_libs/lucide-react.mjs";
import { a as FileField, c as TextField, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice, u as upload } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, g as useMe, i as openFile, l as useChoreEvents, r as nameOf, u as useChores, v as useResidents, y as useSpaces } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cleaning-CImaQoQx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Cleaning() {
	const query = useChores();
	const { data: events = [] } = useChoreEvents();
	const { data: residents = [] } = useResidents();
	const { data: spaces = [] } = useSpaces();
	const { data: me } = useMe();
	const refresh = useRefresh();
	const [mine, setMine] = (0, import_react.useState)(false);
	const chores = query.data ?? [];
	const active = residents.filter((r) => r.active);
	const editor = (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: c ? "Edit duty" : "Add duty",
		trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: c ? "outline" : "default",
			size: c ? "icon" : "default",
			"aria-label": c ? "Edit " + c.name : void 0,
			children: c ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add duty"] })
		}),
		onSave: async (d) => {
			const members = d.getAll("members").map(String);
			const current = text(d, "assigned") || members[0] || null;
			if (current && !members.includes(current)) throw new Error("The assigned resident must belong to the rotation");
			await saveChore(d, {
				choreId: c?.id,
				members
			});
			await refresh();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Name",
				name: "name",
				value: c?.name,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Kind",
				name: "kind",
				value: c?.kind ?? "other",
				required: true,
				options: [
					"washroom",
					"hall",
					"kitchen",
					"garbage",
					"other"
				].map((s) => ({
					id: s,
					name: s
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Space",
				name: "space",
				value: c?.space_id ?? "",
				options: spaces.map((s) => ({
					id: s.id,
					name: s.name
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Every (days)",
					name: "frequency",
					type: "number",
					value: c?.frequency_days ?? 7,
					required: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Next due",
					name: "due",
					type: "date",
					value: c?.next_due ?? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Assigned resident",
				name: "assigned",
				value: c?.current_resident_id ?? "",
				options: active.map((r) => ({
					id: r.id,
					name: r.display_name
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-2 text-sm font-medium",
					children: "Rotation members"
				}), [...active].sort((a, b) => (c?.members.indexOf(a.id) ?? 0) - (c?.members.indexOf(b.id) ?? 0)).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "members",
						value: r.id,
						type: "checkbox",
						defaultChecked: c ? c.members.includes(r.id) : true
					}), r.display_name]
				}, r.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "rotates",
					type: "checkbox",
					defaultChecked: c?.rotates ?? true
				}), "Rotate after completion"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "active",
					type: "checkbox",
					defaultChecked: c?.active ?? true
				}), "Active duty"]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Cleaning",
			sub: "A fair turn for everyone",
			action: me?.isAdmin ? editor() : void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: !mine ? "default" : "outline",
				onClick: () => setMine(false),
				children: "All duties"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: mine ? "default" : "outline",
				onClick: () => setMine(true),
				children: "My duties"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: chores.filter((c) => (c.active || me?.isAdmin) && (!mine || c.current_resident_id === me?.resident?.id)).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								spaces.find((s) => s.id === c.space_id)?.name ?? c.kind,
								" · Every",
								" ",
								c.frequency_days,
								" days"
							]
						})] }), me?.isAdmin && editor(c)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: nameOf(residents, c.current_resident_id) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: !c.active ? "inactive" : c.next_due < (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) ? "overdue" : "due " + c.next_due })]
					}),
					c.needed_reported_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-destructive",
						children: "Cleaning requested"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground break-words",
						children: c.members.map((id) => nameOf(residents, id)).join(" → ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							c.active && c.current_resident_id && (me?.isAdmin || c.current_resident_id === me?.resident?.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
								title: "Complete " + c.name,
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), "Mark complete"]
								}),
								onSave: async (d) => {
									const file = upload(d);
									await completeChore(c.id, d, file);
									await refresh();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileField, {})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
								title: "Request cleaning",
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									children: "Needs cleaning"
								}),
								onSave: async (d) => {
									await reportChoreNeeded(c.id, text(d, "notes"));
									await refresh();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Reason",
									required: true
								})
							}),
							me?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
								title: "Change current turn",
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									children: "Change turn"
								}),
								onSave: async (d) => {
									await choreAdminAction(c.id, text(d, "action"), text(d, "target") || null, text(d, "notes"));
									await refresh();
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										label: "Action",
										name: "action",
										value: "skip",
										required: true,
										options: [
											{
												id: "skip",
												name: "Skip current turn"
											},
											{
												id: "reset",
												name: "Reset rotation"
											},
											{
												id: "reassign",
												name: "Reassign"
											}
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										label: "Resident (for reassign)",
										name: "target",
										options: active.filter((r) => c.members.includes(r.id)).map((r) => ({
											id: r.id,
											name: r.display_name
										}))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
										label: "Reason",
										required: true
									})
								]
							})
						]
					})
				]
			}, c.id))
		}),
		!query.isPending && !chores.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No cleaning duties yet." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-xl font-semibold",
					children: "Recent activity"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y border-y",
					children: events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							chores.find((c) => c.id === e.chore_id)?.name ?? "Duty",
							" ·",
							" ",
							e.event_type.replaceAll("_", " "),
							" · ",
							nameOf(residents, e.resident_id)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground break-words",
							children: [new Date(e.created_at).toLocaleString(), e.reason ? " · " + e.reason : ""]
						})] }), e.photo_media_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							"aria-label": "View completion photo",
							onClick: () => openFile("photos", e.photo_media_id ?? ""),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {})
						})]
					}, e.id))
				}),
				!events.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No activity yet." })
			]
		})
	] });
}
//#endregion
export { Cleaning as component };
