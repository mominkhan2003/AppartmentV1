import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Stat, n as PageHeader, r as Panel } from "./Page-CAF0l6GE.mjs";
import { c as useBalances, g as useMe, m as useIssues, r as nameOf, t as eur, u as useChores, v as useResidents, y as useSpaces } from "./flat-prlcA8Ar.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-rHaeHt6W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fill = {
	bedroom: "var(--chart-1)",
	kitchen: "var(--chart-2)",
	hall: "var(--secondary)",
	balcony: "var(--chart-3)",
	washroom: "var(--chart-4)",
	storage: "var(--muted-foreground)",
	other: "var(--muted)"
};
function centroid(pts) {
	const xs = pts.map((p) => p[0] ?? 0);
	const ys = pts.map((p) => p[1] ?? 0);
	return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2];
}
function FloorPlan({ spaces, residents, highlight, onSelect }) {
	const [mode, setMode] = (0, import_react.useState)("2d");
	const [hover, setHover] = (0, import_react.useState)(null);
	const shapes = spaces.map((s) => ({
		s,
		pts: s.shape ?? []
	})).filter((x) => x.pts.length);
	shapes.sort((a, b) => a.s.kind === "hall" ? -1 : b.s.kind === "hall" ? 1 : 0);
	const layer = (depth, ghost) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "60 20 570 530",
		className: "absolute inset-0 h-full w-full",
		style: { transform: `translateZ(${depth}px)` },
		children: [shapes.map(({ s, pts }) => {
			const active = highlight === s.id || hover === s.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: pts.map((p) => p.join(",")).join(" "),
				fill: ghost ? "var(--foreground)" : fill[s.kind] ?? fill["other"],
				fillOpacity: ghost ? .08 : active ? .95 : .55,
				stroke: "var(--foreground)",
				strokeOpacity: ghost ? .15 : .7,
				strokeWidth: active ? 3 : 1.5,
				className: ghost ? "" : "cursor-pointer transition-all",
				onMouseEnter: ghost ? void 0 : () => setHover(s.id),
				onMouseLeave: ghost ? void 0 : () => setHover(null),
				onClick: ghost ? void 0 : () => onSelect?.(s)
			}, s.id);
		}), !ghost && shapes.map(({ s, pts }) => {
			const [x, y] = centroid(pts);
			const occ = residents.filter((r) => r.room_id === s.id && r.active);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x,
					y,
					textAnchor: "middle",
					fontSize: 13,
					fontWeight: 700,
					fill: "var(--foreground)",
					children: s.code
				}), occ.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x,
					y: y + 14,
					textAnchor: "middle",
					fontSize: 9,
					fill: "var(--foreground)",
					children: occ.map((o) => o.display_name.replace(" (sample)", "")).join(", ")
				})]
			}, s.id + "l");
		})]
	});
	const hovered = spaces.find((s) => s.id === hover);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground",
					children: hovered ? `${hovered.name}${hovered.notes ? " · " + hovered.notes : ""}` : "Hover or tap a space"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-lg border p-0.5 text-sm",
					children: ["2d", "3d"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMode(m),
						className: cn("rounded-md px-3 py-1 uppercase", mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
						children: m
					}, m))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto aspect-[570/530] w-full max-w-xl",
				style: { perspective: 1400 },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-0 transition-transform duration-700",
					style: {
						transformStyle: "preserve-3d",
						transform: mode === "3d" ? "rotateX(55deg) rotateZ(-25deg) scale(0.85)" : "none"
					},
					children: [mode === "3d" && [
						0,
						4,
						8,
						12,
						16
					].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: layer(d, true) }, d)), layer(mode === "3d" ? 20 : 0, false)]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground",
				children: Object.entries({
					bedroom: "Room",
					kitchen: "Kitchen",
					hall: "Hall",
					washroom: "Washroom",
					balcony: "Balcony",
					storage: "Storage"
				}).map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-3 w-3 rounded-sm border",
							style: { background: fill[k] }
						}),
						" ",
						l
					]
				}, k))
			})
		]
	});
}
function Dashboard() {
	const { data: me } = useMe();
	const { data: spaces = [] } = useSpaces();
	const { data: residents = [] } = useResidents();
	const { data: balances = [] } = useBalances();
	const { data: chores = [] } = useChores();
	const { data: issues = [] } = useIssues();
	const [sel, setSel] = (0, import_react.useState)(null);
	const myBal = balances.find((b) => b.resident_id === me?.resident?.id)?.balance_cents ?? 0;
	const myChores = chores.filter((c) => c.current_resident_id === me?.resident?.id && c.active);
	const open = issues.filter((i) => i.status !== "resolved");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: `Hi ${me?.resident?.display_name ?? ""}`,
			sub: "Here's what's happening in the flat."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "My balance",
					value: eur(myBal),
					tone: myBal < 0 ? "bad" : "good"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "My duties now",
					value: myChores.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Open issues",
					value: open.length
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloorPlan, {
				spaces,
				residents,
				highlight: sel?.id,
				onSelect: setSel
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					sel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: sel.name,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm capitalize text-muted-foreground",
								children: [sel.kind, sel.notes ? ` · ${sel.notes}` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 text-sm",
								children: residents.filter((r) => r.room_id === sel.id).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: r.display_name }, r.id))
							}),
							chores.filter((c) => c.space_id === sel.id).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm",
								children: [
									c.name,
									": ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: nameOf(residents, c.current_resident_id) }),
									", due ",
									c.next_due
								]
							}, c.id))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: "Cleaning this week",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 text-sm",
							children: chores.filter((c) => c.active).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [
										nameOf(residents, c.current_resident_id),
										" · ",
										c.next_due
									]
								})]
							}, c.id))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cleaning",
							className: "mt-3 inline-block text-sm text-primary underline",
							children: "Open cleaning"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Latest issues",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-2 text-sm",
							children: [open.slice(0, 4).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: i.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "capitalize text-muted-foreground",
									children: i.status.replace("_", " ")
								})]
							}, i.id)), !open.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-muted-foreground",
								children: "Nothing open 🎉"
							})]
						})
					})
				]
			})]
		})
	] });
}
//#endregion
export { Dashboard as component };
