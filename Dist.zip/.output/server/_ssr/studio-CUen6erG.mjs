import { i as openMedia, r as mediaUrl } from "./api-Bz4c_dXI.mjs";
import { F as listSocialPosts, b as deleteSocialPost, ft as studioMeta, p as createSocialPost } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { I as Download, r as WandSparkles, u as Trash2 } from "../_libs/lucide-react.mjs";
import { c as TextField, n as DataState, o as Notes, r as Editor, u as upload } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { i as formatUtc } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-CUen6erG.js
var import_jsx_runtime = require_jsx_runtime();
function Studio() {
	const me = useMe();
	const qc = useQueryClient();
	const posts = useQuery({
		queryKey: ["social-posts"],
		queryFn: listSocialPosts
	});
	const meta = useQuery({
		queryKey: ["studio-meta"],
		queryFn: studioMeta
	});
	const refresh = () => qc.invalidateQueries({ queryKey: ["social-posts"] });
	if (!me.data?.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-destructive",
		children: "Only administrators use the post studio."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Social post studio",
			sub: "Save finished graphics (PNG/JPEG) with their Instagram captions in both languages."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 grid gap-5 rounded-2xl border bg-card p-5 lg:grid-cols-[300px_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: meta }),
				meta.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-4",
					onSubmit: async (e) => {
						e.preventDefault();
						const form = new FormData(e.currentTarget);
						if (!upload(form)) throw new Error("Attach the exported graphic (PNG or JPEG)");
						await createSocialPost(form);
						e.target.reset();
						await refresh();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm font-medium",
							children: ["Format", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								name: "format",
								className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
								children: meta.data.formats.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: f.id,
									children: [
										f.name,
										" (",
										f.width,
										"×",
										f.height,
										")"
									]
								}, f.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm font-medium",
							children: ["Template", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								name: "template",
								className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
								children: meta.data.templates.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: t.id,
									children: t.name
								}, t.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Headline (reference)",
							name: "headline"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm font-medium",
							children: ["Graphic (PNG/JPEG)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								name: "file",
								accept: "image/png,image/jpeg",
								required: true,
								className: "text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Caption (German)",
							name: "de[caption]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Caption (English)",
							name: "en[caption]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "h-4 w-4" }), "Save post"] }) })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: posts }),
					posts.data && posts.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No posts saved yet." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
						children: (posts.data ?? []).map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
							post,
							onChanged: refresh
						}, post.id))
					})
				] })
			]
		})]
	});
}
function PostCard({ post, onChanged }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-xl border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => openMedia(post.media_id),
				"aria-label": "View post " + (post.headline ?? post.id),
				className: "block w-full overflow-hidden rounded-lg border bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: mediaUrl(post.media_id ?? ""),
					alt: post.headline ?? "",
					className: "h-40 w-full object-cover",
					loading: "lazy"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "mt-2 space-y-1 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium text-foreground",
						children: post.headline ?? "Untitled post"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						post.format,
						" · ",
						post.mime_type,
						" · ",
						formatUtc(post.created_at)
					] }),
					post.captions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-h-16 overflow-y-auto break-words",
						children: post.captions
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => openMedia(post.media_id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), "Download"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
					title: "Delete post",
					destructive: true,
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "text-destructive",
						"aria-label": "Delete post",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					}),
					onSave: async () => {
						await deleteSocialPost(post.id);
						await onChanged();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Delete the graphic and its captions?"
					})
				})]
			})
		]
	});
}
//#endregion
export { Studio as component };
