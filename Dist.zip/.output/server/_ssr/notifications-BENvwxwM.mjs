import { R as markNotificationsRead, z as notifications } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { B as CheckCheck } from "../_libs/lucide-react.mjs";
import { n as DataState } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as formatUtc } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-BENvwxwM.js
var import_jsx_runtime = require_jsx_runtime();
function Notifications() {
	const qc = useQueryClient();
	const query = useQuery({
		queryKey: ["notifications"],
		queryFn: notifications
	});
	const refresh = async () => {
		await qc.invalidateQueries({ queryKey: ["notifications"] });
	};
	const rows = query.data?.items ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Notifications",
				sub: query.data ? query.data.unread ? `${query.data.unread} unread` : "You are all caught up" : void 0,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					disabled: !query.data || query.data.unread === 0,
					onClick: async () => {
						await markNotificationsRead();
						await refresh();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-4 w-4" }), "Mark all read"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
			query.data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No notifications — quiet in the flat right now." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y border-y",
				children: rows.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "py-4" + (n.read_at ? "" : " bg-primary/5"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "break-words" + (n.read_at ? " font-medium" : " font-semibold"),
									children: n.title
								}),
								n.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 break-words text-sm text-muted-foreground",
									children: n.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: [
										formatUtc(n.created_at),
										" · ",
										n.audience === "admin" ? "Admin notice" : "Personal"
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [n.link && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: n.link,
									children: "Open"
								})
							}), !n.read_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: async () => {
									await markNotificationsRead(n.id);
									await refresh();
								},
								children: "Mark read"
							})]
						})]
					})
				}, n.id))
			})
		]
	});
}
//#endregion
export { Notifications as component };
