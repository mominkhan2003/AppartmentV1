import { r as __toESM } from "../_runtime.mjs";
import { n as api } from "./api-Bz4c_dXI.mjs";
import { B as pageHead } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { G as redirect, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BS0z_v-u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var styles_default = "/assets/styles-DT_p8plu.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$28 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "FlatMate Hub" },
			{
				name: "description",
				content: "Shared flat management: expenses, cleaning, issues and floor plan."
			},
			{
				property: "og:title",
				content: "FlatMate Hub"
			},
			{
				property: "og:description",
				content: "Shared flat management: expenses, cleaning, issues and floor plan."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700&family=Figtree:wght@400;500;600&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$28.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			richColors: true,
			position: "top-right"
		})]
	});
}
var $$splitComponentImporter$27 = () => import("./routes-DEh_M-a5.mjs");
var Route$27 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "FlatMate Hub — run your shared flat together" },
		{
			name: "description",
			content: "Split expenses, rotate cleaning duties, report issues and see your flat's floor plan in one place."
		},
		{
			property: "og:title",
			content: "FlatMate Hub — run your shared flat together"
		},
		{
			property: "og:description",
			content: "Split expenses, rotate cleaning duties, report issues and see your flat's floor plan."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./route-SPNU2gSQ.mjs");
var Route$26 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		try {
			await api.get("/auth/me");
		} catch {
			throw redirect({ to: "/auth" });
		}
	},
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./auth-Cjjp0E3P.mjs");
var Route$25 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Sign in — FlatMate Hub" },
		{
			name: "description",
			content: "Sign in to your shared flat's FlatMate Hub."
		},
		{
			property: "og:title",
			content: "Sign in — FlatMate Hub"
		},
		{
			property: "og:description",
			content: "Sign in to your shared flat's FlatMate Hub."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./reset-password-B4MUPi6U.mjs");
var Route$24 = createFileRoute("/reset-password")({
	head: () => pageHead("Reset password", "Set a new password for your FlatMate Hub account."),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./account-C_T-q1Vw.mjs");
var Route$23 = createFileRoute("/_authenticated/account")({
	head: () => pageHead("My account", "Manage your FlatMate Hub name, login email and password."),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./admin-C48GCxJI.mjs");
var Route$22 = createFileRoute("/_authenticated/admin")({
	head: () => pageHead("Admin Portal", "Manage household groups, room access, admin permissions and the audit history."),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./balance-D8K_wHLx.mjs");
var Route$21 = createFileRoute("/_authenticated/balance")({
	head: () => pageHead("My Balance", "Your household balance, approved credits, payments and transaction history."),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./bookings-DvZx8eLR.mjs");
var Route$20 = createFileRoute("/_authenticated/bookings")({
	head: () => pageHead("Resource bookings", "Reserve shared spaces and equipment without overlapping bookings."),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./cleaning-CImaQoQx.mjs");
var Route$19 = createFileRoute("/_authenticated/cleaning")({
	head: () => pageHead("Cleaning", "Cleaning assignments, rotation order, completion photos and duty history."),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./contacts-RdmdEk9r.mjs");
var Route$18 = createFileRoute("/_authenticated/contacts")({
	head: () => pageHead("Useful contacts", "Landlord, maintenance and local service contacts."),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./content-_Y3WiSR2.mjs");
var Route$17 = createFileRoute("/_authenticated/content")({
	head: () => pageHead("Homepage content", "Edit the public homepage copy, order sections and manage site settings."),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
/** Reorders one area's codes by swapping the section at `index` with its new neighbour. */
var $$splitComponentImporter$16 = () => import("./dashboard-rHaeHt6W.mjs");
var Route$16 = createFileRoute("/_authenticated/dashboard")({
	head: () => pageHead("Overview", "Your FlatMate Hub balances, cleaning duties, issues and apartment floor plan."),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./documents-DNH_mLZp.mjs");
var Route$15 = createFileRoute("/_authenticated/documents")({
	head: () => pageHead("Shared documents", "Household document links in one place."),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./donations-CmSq5lND.mjs");
var Route$14 = createFileRoute("/_authenticated/donations")({
	head: () => pageHead("Donations", "Incoming donation requests, confirmed transactions and finance categories."),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./events-gyfVHYcV.mjs");
var Route$13 = createFileRoute("/_authenticated/events")({
	head: () => pageHead("Events", "Household gatherings and resident RSVPs."),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./events-plan-0oCiVM1n.mjs");
var Route$12 = createFileRoute("/_authenticated/events-plan")({
	head: () => pageHead("Public events", "Plan public flat events, translations and team shifts."),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
/** PATCH /shifts/:id keeps the same field shape used when creating a shift. */
var $$splitComponentImporter$11 = () => import("./expenses-DQlhaTHN.mjs");
var Route$11 = createFileRoute("/_authenticated/expenses")({
	head: () => pageHead("Expenses", "Shared costs, receipts, reimbursement claims and approval history."),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./inventory-DO5EjCgS.mjs");
var Route$10 = createFileRoute("/_authenticated/inventory")({
	head: () => pageHead("Shared inventory", "Track shared belongings, borrowing and returns."),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./issues-Bp3qDquA.mjs");
var Route$9 = createFileRoute("/_authenticated/issues")({
	head: () => pageHead("Issues", "Report household problems and follow assignments, responses and resolutions."),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./lost-found-Bs3FLb0m.mjs");
var Route$8 = createFileRoute("/_authenticated/lost-found")({
	head: () => pageHead("Lost & found", "Report missing belongings and claim found items."),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./media-3QeSeYqS.mjs");
var Route$7 = createFileRoute("/_authenticated/media")({
	head: () => pageHead("Media library", "Website graphics, uploaded by the admin and reused across the site."),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./notices-DGb4ZiKz.mjs");
var Route$6 = createFileRoute("/_authenticated/notices")({
	head: () => pageHead("Noticeboard", "Household announcements and acknowledgements."),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./notifications-BENvwxwM.mjs");
var Route$5 = createFileRoute("/_authenticated/notifications")({
	head: () => pageHead("Notifications", "System messages from the hub: new requests, chores and issues."),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./polls-C4h_cIve.mjs");
var Route$4 = createFileRoute("/_authenticated/polls")({
	head: () => pageHead("Household polls", "Vote on household decisions and see live results."),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./residents-CysKK71U.mjs");
var Route$3 = createFileRoute("/_authenticated/residents")({
	head: () => pageHead("Residents", "Residents, room assignments, contact details and household groups."),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./rules-STPXxdC4.mjs");
var Route$2 = createFileRoute("/_authenticated/rules")({
	head: () => pageHead("House rules", "Household agreements and resident acknowledgements."),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./shopping-U37vx_Ba.mjs");
var Route$1 = createFileRoute("/_authenticated/shopping")({
	head: () => pageHead("Shopping list", "Shared groceries and household essentials."),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./studio-CUen6erG.mjs");
var Route = createFileRoute("/_authenticated/studio")({
	head: () => pageHead("Social post studio", "Export branded graphics and keep the matching captions."),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$27.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$28
});
var AuthenticatedRouteRoute = Route$26.update({
	id: "/_authenticated",
	getParentRoute: () => Route$28
});
var AuthRoute = Route$25.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$28
});
var ResetPasswordRoute = Route$24.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$28
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAccountRoute: Route$23.update({
		id: "/account",
		path: "/account",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedAdminRoute: Route$22.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedBalanceRoute: Route$21.update({
		id: "/balance",
		path: "/balance",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedBookingsRoute: Route$20.update({
		id: "/bookings",
		path: "/bookings",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedCleaningRoute: Route$19.update({
		id: "/cleaning",
		path: "/cleaning",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedContactsRoute: Route$18.update({
		id: "/contacts",
		path: "/contacts",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedContentRoute: Route$17.update({
		id: "/content",
		path: "/content",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDashboardRoute: Route$16.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDocumentsRoute: Route$15.update({
		id: "/documents",
		path: "/documents",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDonationsRoute: Route$14.update({
		id: "/donations",
		path: "/donations",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedEventsRoute: Route$13.update({
		id: "/events",
		path: "/events",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedEventsPlanRoute: Route$12.update({
		id: "/events-plan",
		path: "/events-plan",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedExpensesRoute: Route$11.update({
		id: "/expenses",
		path: "/expenses",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedInventoryRoute: Route$10.update({
		id: "/inventory",
		path: "/inventory",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedIssuesRoute: Route$9.update({
		id: "/issues",
		path: "/issues",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLostFoundRoute: Route$8.update({
		id: "/lost-found",
		path: "/lost-found",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedMediaRoute: Route$7.update({
		id: "/media",
		path: "/media",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedNoticesRoute: Route$6.update({
		id: "/notices",
		path: "/notices",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedNotificationsRoute: Route$5.update({
		id: "/notifications",
		path: "/notifications",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPollsRoute: Route$4.update({
		id: "/polls",
		path: "/polls",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedResidentsRoute: Route$3.update({
		id: "/residents",
		path: "/residents",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedRulesRoute: Route$2.update({
		id: "/rules",
		path: "/rules",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedShoppingRoute: Route$1.update({
		id: "/shopping",
		path: "/shopping",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedStudioRoute: Route.update({
		id: "/studio",
		path: "/studio",
		getParentRoute: () => AuthenticatedRouteRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AuthRoute,
	ResetPasswordRoute
};
var routeTree = Route$28._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
