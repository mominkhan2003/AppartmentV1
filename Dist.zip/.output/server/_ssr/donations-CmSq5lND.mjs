import { r as __toESM } from "../_runtime.mjs";
import { $ as saveDonationCategory, M as listDonationTransactions, dt as siteSettings, h as deleteDonationTransaction, it as saveSiteSettings, j as listDonationRequests, l as createDonationTransaction, m as deleteDonationCategory, mt as updateDonationRequest, x as donationCategories } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { u as Trash2, y as Plus } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice } from "./Forms-Cipd7J0Q.mjs";
import { i as Stat, n as PageHeader } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { r as eurCms } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donations-CmSq5lND.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var toCents = (v) => Math.round(parseFloat(v.replace(",", ".")) * 100);
function Donations() {
	const me = useMe();
	const [tab, setTab] = (0, import_react.useState)("requests");
	if (!me.data?.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-destructive",
		children: "Only administrators manage the donation finance records."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Donations",
				sub: "Everything handled here is private; the homepage only ever shows totals."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex flex-wrap gap-2",
				children: [
					{
						id: "requests",
						label: "Requests"
					},
					{
						id: "transactions",
						label: "Finance"
					},
					{
						id: "categories",
						label: "Categories"
					},
					{
						id: "settings",
						label: "Settings"
					}
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === t.id ? "default" : "outline",
					onClick: () => setTab(t.id),
					children: t.label
				}, t.id))
			}),
			tab === "requests" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestsTab, {}),
			tab === "transactions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionsTab, {}),
			tab === "categories" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoriesTab, {}),
			tab === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsTab, {})
		]
	});
}
function RequestsTab() {
	const qc = useQueryClient();
	const [status, setStatus] = (0, import_react.useState)("");
	const requests = useQuery({
		queryKey: ["donation-requests", status],
		queryFn: () => listDonationRequests({ status: status || void 0 })
	});
	const refresh = () => qc.invalidateQueries({ queryKey: ["donation-requests"] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: status,
				onChange: (e) => setStatus(e.target.value),
				className: "h-9 w-40 rounded-md border bg-background px-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "All requests"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "new",
						children: "New"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "credited",
						children: "Credited"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "declined",
						children: "Declined"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "spam",
						children: "Spam"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: requests }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y border-y",
			children: [(requests.data?.items ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex flex-wrap items-start justify-between gap-3 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: r.contact_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: r.status }),
								r.category_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground",
									children: r.category_name
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 break-all text-sm text-muted-foreground",
							children: [
								r.contact_email,
								r.contact_phone ? ` · ${r.contact_phone}` : "",
								r.amount_cents !== null ? ` · offers ${eurCms(r.amount_cents)}` : " · no amount given",
								" · ",
								r.created_at.slice(0, 10)
							]
						}),
						r.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-3xl break-words text-sm",
							children: r.message
						}),
						r.internal_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: ["Internal: ", r.internal_notes]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [r.status !== "credited" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
						title: "Credit donation",
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							children: "Record arrival"
						}),
						onSave: async (d) => {
							await createDonationTransaction({
								amount_cents: toCents(text(d, "amount")),
								transaction_date: text(d, "transaction_date"),
								method: text(d, "method") || "bank_transfer",
								category_id: text(d, "category_id") || null,
								donor_name: r.contact_name,
								request_id: r.id,
								reference: text(d, "reference") || null,
								note: text(d, "note") || null
							});
							await refresh();
							await qc.invalidateQueries({ queryKey: ["donation-transactions"] });
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "Recording marks the request as credited."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Amount received (EUR)",
								name: "amount",
								type: "number",
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Date",
								name: "transaction_date",
								type: "date",
								value: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Method",
								name: "method",
								value: "bank_transfer",
								options: [
									{
										id: "bank_transfer",
										name: "Bank transfer"
									},
									{
										id: "cash",
										name: "Cash"
									},
									{
										id: "other",
										name: "Other"
									}
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategorySelect, { name: "category_id" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Reference",
								name: "reference"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
								label: "Internal note",
								name: "note"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
						title: "Update request",
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							children: "Manage"
						}),
						onSave: async (d) => {
							await updateDonationRequest(r.id, {
								status: text(d, "status") || void 0,
								internal_notes: text(d, "internal_notes") || null
							});
							await refresh();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							label: "Status",
							name: "status",
							value: r.status,
							options: [
								{
									id: "new",
									name: "New"
								},
								{
									id: "credited",
									name: "Credited"
								},
								{
									id: "declined",
									name: "Declined"
								},
								{
									id: "spam",
									name: "Spam"
								}
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Internal notes",
							name: "internal_notes",
							value: r.internal_notes ?? ""
						})]
					})]
				})]
			}, r.id)), requests.data && requests.data.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-sm text-muted-foreground",
				children: "No requests in this view."
			})]
		})
	] });
}
function CategorySelect({ name, value, required = false }) {
	const cats = useQuery({
		queryKey: ["donation-categories"],
		queryFn: donationCategories
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2 text-sm font-medium",
		children: [
			"Purpose",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				name,
				defaultValue: value ?? "",
				required,
				className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "—"
				}), (cats.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: c.id,
					children: c.name
				}, c.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: cats })
		]
	});
}
function TransactionsTab() {
	const qc = useQueryClient();
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const transactions = useQuery({
		queryKey: [
			"donation-transactions",
			from,
			to,
			category
		],
		queryFn: () => listDonationTransactions({
			from: from || void 0,
			to: to || void 0,
			category_id: category || void 0
		})
	});
	const cats = useQuery({
		queryKey: ["donation-categories"],
		queryFn: donationCategories
	});
	const refresh = () => qc.invalidateQueries({ queryKey: ["donation-transactions"] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Total in view",
					value: eurCms(transactions.data?.sum_amount_cents ?? 0),
					tone: "good"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Entries",
					value: String(transactions.data?.total ?? 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-2 flex flex-wrap items-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-xs text-muted-foreground",
							children: ["From", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: from,
								onChange: (e) => setFrom(e.target.value),
								className: "h-9 rounded-md border bg-background px-2 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-xs text-muted-foreground",
							children: ["To", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: to,
								onChange: (e) => setTo(e.target.value),
								className: "h-9 rounded-md border bg-background px-2 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "h-9 w-36 rounded-md border bg-background px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "All categories"
							}), (cats.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: transactions }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y border-y",
			children: [(transactions.data?.items ?? []).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								eurCms(t.amount_cents),
								" · ",
								t.method.replaceAll("_", " ")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								t.transaction_date,
								t.category_name ? ` · ${t.category_name}` : "",
								t.donor_name ? ` · ${t.donor_name}` : "",
								t.reference ? ` · ref ${t.reference}` : ""
							]
						}),
						t.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: t.note
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
					title: "Delete transaction",
					destructive: true,
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "text-destructive",
						"aria-label": "Delete transaction",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					}),
					onSave: async () => {
						await deleteDonationTransaction(t.id);
						await refresh();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Remove this ",
							eurCms(t.amount_cents),
							" entry from the finance log?"
						]
					})
				})]
			}, t.id)), transactions.data && transactions.data.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-sm text-muted-foreground",
				children: "No transactions match."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
				title: "Record donation",
				trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Record donation"] }),
				onSave: async (d) => {
					await createDonationTransaction({
						amount_cents: toCents(text(d, "amount")),
						transaction_date: text(d, "transaction_date"),
						method: text(d, "method") || "bank_transfer",
						category_id: text(d, "category_id") || null,
						donor_name: text(d, "donor_name") || null,
						reference: text(d, "reference") || null,
						note: text(d, "note") || null
					});
					await refresh();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Amount (EUR)",
						name: "amount",
						type: "number",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Date",
						name: "transaction_date",
						type: "date",
						value: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Method",
						name: "method",
						value: "bank_transfer",
						options: [
							{
								id: "bank_transfer",
								name: "Bank transfer"
							},
							{
								id: "cash",
								name: "Cash"
							},
							{
								id: "other",
								name: "Other"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategorySelect, { name: "category_id" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Donor name (optional)",
						name: "donor_name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Reference (e.g. bank memo)",
						name: "reference"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
						label: "Internal note",
						name: "note"
					})
				]
			})
		})
	] });
}
function CategoriesTab() {
	const qc = useQueryClient();
	const cats = useQuery({
		queryKey: ["donation-categories"],
		queryFn: donationCategories
	});
	const refresh = () => qc.invalidateQueries({ queryKey: ["donation-categories"] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: cats }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y border-y",
				children: (cats.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: c.name
							}),
							c.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: c.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: ["Sort order ", c.sort]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
							title: "Edit category",
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								children: "Edit"
							}),
							onSave: async (d) => {
								await saveDonationCategory(c.id, {
									name: text(d, "name"),
									description: text(d, "description") || null,
									sort: parseInt(text(d, "sort") || "0", 10) || 0
								});
								await refresh();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
									label: "Name",
									name: "name",
									value: c.name,
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Description",
									name: "description",
									value: c.description ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
									label: "Sort order",
									name: "sort",
									type: "number",
									value: String(c.sort)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
							title: "Delete " + c.name,
							destructive: true,
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								className: "text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), "Delete"]
							}),
							onSave: async () => {
								await deleteDonationCategory(c.id);
								await refresh();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									"Remove “",
									c.name,
									"”? Existing transactions keep their history."
								]
							})
						})]
					})]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
					title: "Add category",
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Add category"]
					}),
					onSave: async (d) => {
						await saveDonationCategory(null, {
							name: text(d, "name"),
							description: text(d, "description") || null,
							sort: parseInt(text(d, "sort") || "0", 10) || 0
						});
						await refresh();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Name",
							name: "name",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Description",
							name: "description"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Sort order",
							name: "sort",
							type: "number",
							value: "0"
						})
					]
				})
			})
		]
	});
}
function SettingsTab() {
	const qc = useQueryClient();
	const settings = useQuery({
		queryKey: ["site-settings"],
		queryFn: siteSettings
	});
	const refresh = async () => {
		await Promise.all([qc.invalidateQueries({ queryKey: ["site-settings"] }), qc.invalidateQueries({ queryKey: ["public-homepage"] })]);
	};
	const values = Object.fromEntries((settings.data ?? []).map((r) => [r.setting_key, r.setting_value]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl rounded-xl border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: settings }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: async (e) => {
				e.preventDefault();
				const d = new FormData(e.currentTarget);
				await saveSiteSettings({
					donations_public: d.get("donations_public") === "on" ? "1" : "0",
					donations_goal: text(d, "donations_goal"),
					donations_account: text(d, "donations_account"),
					donations_instructions: text(d, "donations_instructions")
				});
				await refresh();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "grid gap-2 text-sm font-medium",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							name: "donations_public",
							defaultChecked: values.donations_public === "1"
						}), " Show the donation area on the public homepage"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Goal (EUR)",
					name: "donations_goal",
					type: "number",
					value: values.donations_goal ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Account details ('Flat IBAN AT…')",
					name: "donations_account",
					value: values.donations_account ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
					label: "Public instructions",
					name: "donations_instructions",
					value: values.donations_instructions ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Save donation settings" }) })
			]
		})]
	});
}
//#endregion
export { Donations as component };
