import { r as __toESM } from "../_runtime.mjs";
import { r as mediaUrl } from "./api-Bz4c_dXI.mjs";
import { C as getEvent, N as listEvents, S as duplicateEvent, g as deleteEvent, ht as updateEvent, nt as saveShift, r as assignShift, st as setEventStatus, u as createEvent, y as deleteShift, yt as updateShift } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Copy, V as CalendarDays, u as Trash2, y as Plus } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { a as toUtc, i as formatUtc, n as ResidentSelect, o as utcToLocal, t as MediaSelect } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events-plan-0oCiVM1n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	{
		id: "community",
		name: "Community"
	},
	{
		id: "cooking",
		name: "Cooking"
	},
	{
		id: "organizing",
		name: "Organizing"
	},
	{
		id: "cleaning",
		name: "Cleaning"
	},
	{
		id: "other",
		name: "Other"
	}
];
function EventsPlan() {
	const me = useMe();
	const qc = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const events = useQuery({
		queryKey: [
			"events",
			filter,
			page
		],
		queryFn: () => listEvents({
			status: filter || void 0,
			page
		})
	});
	const refresh = () => qc.invalidateQueries({ queryKey: ["events"] });
	if (!me.data?.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-destructive",
		children: "Only administrators can plan public events."
	});
	const pages = events.data ? Math.max(1, Math.ceil(events.data.total / events.data.per_page)) : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Public events",
				sub: "Published events appear on the public homepage with translations.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventEditor, { onSaved: refresh })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex flex-wrap gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: filter,
					onChange: (e) => {
						setFilter(e.target.value);
						setPage(1);
					},
					className: "h-9 w-40 rounded-md border bg-background px-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All statuses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "draft",
							children: "Draft"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "published",
							children: "Published"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "archived",
							children: "Archived"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: events }),
			events.data && events.data.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No events yet — create the first one." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: (events.data?.items ?? []).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventCard, {
					event,
					onChanged: refresh
				}, event.id))
			}),
			pages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-center gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: page <= 1,
						onClick: () => setPage(page - 1),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Page ",
						page,
						" of ",
						pages
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: page >= pages,
						onClick: () => setPage(page + 1),
						children: "Next"
					})
				]
			})
		]
	});
}
function EventEditor({ event, onSaved }) {
	const de = event?.translations.find((t) => t.locale === "de");
	const en = event?.translations.find((t) => t.locale === "en");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: event ? "Edit event" : "Create event",
		trigger: event ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "ghost",
			"aria-label": "Edit event " + (de?.title ?? en?.title ?? event.slug),
			children: "Edit"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-4 w-4" }), "Create event"] }),
		onSave: async (d) => {
			const body = {
				starts_at: toUtc(text(d, "starts_at")),
				ends_at: toUtc(text(d, "ends_at")) ?? null,
				category: text(d, "category") || "other",
				meeting_point: text(d, "meeting_point") || null,
				address: text(d, "address") || null,
				cover_media_id: text(d, "cover_media_id") || null,
				additional_info: text(d, "additional_info") || null,
				de: {
					title: text(d, "de_title"),
					description: text(d, "de_description")
				},
				en: {
					title: text(d, "en_title"),
					description: text(d, "en_description")
				}
			};
			if (!body.de.title && !body.en.title) throw new Error("Provide a title in German or English");
			if (event) await updateEvent(event.id, body);
			else await createEvent(body);
			await onSaved();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Title (German)",
				name: "de_title",
				value: de?.title ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Description (German)",
				name: "de_description",
				value: de?.description ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Title (English)",
				name: "en_title",
				value: en?.title ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Description (English)",
				name: "en_description",
				value: en?.description ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Starts",
					name: "starts_at",
					type: "datetime-local",
					value: event ? utcToLocal(event.starts_at) : "",
					required: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Ends (optional)",
					name: "ends_at",
					type: "datetime-local",
					value: event?.ends_at ? utcToLocal(event.ends_at) : ""
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Category",
				name: "category",
				value: event?.category ?? "community",
				options: CATEGORIES
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Meeting point",
				name: "meeting_point",
				value: event?.meeting_point ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Address",
				name: "address",
				value: event?.address ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaSelect, {
				label: "Cover image",
				name: "cover_media_id",
				value: event?.cover_media_id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Additional info (e.g. what to bring)",
				name: "additional_info",
				value: event?.additional_info ?? ""
			})
		]
	});
}
function EventCard({ event, onChanged }) {
	const [openShifts, setOpenShifts] = (0, import_react.useState)(false);
	const detail = useQuery({
		queryKey: ["event", event.id],
		enabled: openShifts,
		queryFn: () => getEvent(event.id)
	});
	const title = event.translations[0]?.title ?? event.slug;
	const cover = event.cover_media_id ? mediaUrl(event.cover_media_id) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start gap-4",
			children: [
				cover && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: cover,
					alt: "",
					className: "h-14 w-20 rounded-lg border object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: event.status })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							formatUtc(event.starts_at),
							" · ",
							event.category,
							event.meeting_point ? ` · ${event.meeting_point}` : ""
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventEditor, {
							event,
							onSaved: onChanged
						}),
						event.status !== "published" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: async () => {
								await setEventStatus(event.id, "published");
								await onChanged();
							},
							children: "Publish"
						}),
						event.status === "published" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: async () => {
								await setEventStatus(event.id, "draft");
								await onChanged();
							},
							children: "Unpublish"
						}),
						event.status !== "archived" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: async () => {
								await setEventStatus(event.id, "archived");
								await onChanged();
							},
							children: "Archive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: async () => {
								await duplicateEvent(event.id);
								await onChanged();
							},
							"aria-label": "Duplicate " + title,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Duplicate"
								}),
								"Copy"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
							title: "Delete " + title,
							destructive: true,
							trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								className: "text-destructive",
								"aria-label": "Delete " + title,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), "Delete"]
							}),
							onSave: async () => {
								await deleteEvent(event.id);
								await onChanged();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "Delete the event including translations and shifts?"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setOpenShifts((v) => !v),
							children: ["Shifts ", detail.data ? `(${detail.data.shifts.length})` : ""]
						})
					]
				})
			]
		}), openShifts && (detail.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-3 text-sm text-muted-foreground",
			children: "Loading shifts…"
		}) : detail.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: detail }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShiftsPanel, {
			eventId: event.id,
			shifts: detail.data?.shifts ?? [],
			onChanged: async () => {
				await detail.refetch();
				await onChanged();
			}
		}))]
	});
}
function ShiftsPanel({ eventId, shifts, onChanged }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 border-t pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-sm font-semibold uppercase text-muted-foreground",
					children: "Team shifts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
					title: "Add shift",
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Add shift"]
					}),
					onSave: async (d) => {
						await saveShift(eventId, {
							name: text(d, "name"),
							starts_at: toUtc(text(d, "starts_at")),
							ends_at: toUtc(text(d, "ends_at")) ?? null,
							slots: Math.max(1, parseInt(text(d, "slots") || "1", 10) || 1),
							notes: text(d, "notes") || null
						});
						await onChanged();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Shift name",
							name: "name",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Starts",
								name: "starts_at",
								type: "datetime-local",
								required: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Ends",
								name: "ends_at",
								type: "datetime-local"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Number of slots",
							name: "slots",
							type: "number",
							value: "1",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Notes",
							name: "notes"
						})
					]
				})]
			}),
			!shifts.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No shifts planned for this event." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2",
				children: shifts.map((shift) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: shift.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									formatUtc(shift.starts_at),
									" — ",
									formatUtc(shift.ends_at),
									" · ",
									shift.planned_count,
									"/",
									shift.slots,
									" filled"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
									title: "Edit shift",
									trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										children: "Edit"
									}),
									onSave: async (d) => {
										await saveShiftUpdate(shift.id, d);
										await onChanged();
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
											label: "Shift name",
											name: "name",
											value: shift.name,
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
												label: "Starts",
												name: "starts_at",
												type: "datetime-local",
												value: utcToLocal(shift.starts_at),
												required: true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
												label: "Ends",
												name: "ends_at",
												type: "datetime-local",
												value: shift.ends_at ? utcToLocal(shift.ends_at) : ""
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
											label: "Number of slots",
											name: "slots",
											type: "number",
											value: String(shift.slots),
											required: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
											label: "Notes",
											name: "notes",
											value: shift.notes ?? ""
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
									title: "Delete " + shift.name,
									destructive: true,
									trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										className: "text-destructive",
										"aria-label": "Delete shift " + shift.name,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									}),
									onSave: async () => {
										await deleteShift(shift.id);
										await onChanged();
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm",
										children: "Remove this shift and its assignments?"
									})
								})]
							})]
						}),
						shift.assignments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1 text-sm",
							children: shift.assignments.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									a.display_name ?? a.resident_id,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: a.status })
								] }), a.status !== "declined" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: async () => {
										await assignShift(shift.id, {
											resident_id: a.resident_id,
											status: "declined"
										});
										await onChanged();
									},
									children: "Remove"
								})]
							}, a.resident_id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShiftAssignEditor, {
							shiftId: shift.id,
							slots: shift.slots,
							filled: shift.planned_count,
							onChanged
						})
					]
				}, shift.id))
			})
		]
	});
}
/** PATCH /shifts/:id keeps the same field shape used when creating a shift. */
async function saveShiftUpdate(shiftId, d) {
	await updateShift(shiftId, {
		name: text(d, "name"),
		starts_at: toUtc(text(d, "starts_at")),
		ends_at: toUtc(text(d, "ends_at")) ?? null,
		slots: Math.max(1, parseInt(text(d, "slots") || "1", 10) || 1),
		notes: text(d, "notes") || null
	});
}
function ShiftAssignEditor({ shiftId, slots, filled, onChanged }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: "Assign resident",
		trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "outline",
			children: "Assign"
		}),
		onSave: async (d) => {
			await assignShift(shiftId, {
				resident_id: text(d, "resident_id"),
				status: text(d, "status") || "planned",
				note: text(d, "note") || null
			});
			await onChanged();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResidentSelect, {
				label: "Resident",
				name: "resident_id",
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Status",
				name: "status",
				value: "planned",
				options: [{
					id: "planned",
					name: "Planned"
				}, {
					id: "confirmed",
					name: "Confirmed"
				}]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Note",
				name: "note"
			}),
			filled >= slots && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "All slots are already taken — remove someone first."
			})
		]
	});
}
//#endregion
export { EventsPlan as component };
