import { r as __toESM } from "../_runtime.mjs";
import { G as recordSharedExpense, Z as reviewClaim, pt as submitClaim, xt as voidExpense } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { M as FileText, t as X, y as Plus, z as Check } from "../_libs/lucide-react.mjs";
import { a as FileField, c as TextField, i as Field, l as text, n as DataState, o as Notes, r as Editor, s as Status, t as Choice, u as upload } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, a as toCents, d as useExpenseShares, f as useExpenses, g as useMe, i as openFile, n as fileHash, o as uploadFile, p as useGroups, t as eur, v as useResidents } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/expenses-DQlhaTHN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Expenses() {
	const query = useExpenses();
	const { data: residents = [] } = useResidents();
	const { data: groups = [] } = useGroups();
	const { data: me } = useMe();
	const refresh = useRefresh();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [group, setGroup] = (0, import_react.useState)("");
	const [custom, setCustom] = (0, import_react.useState)(false);
	const shares = useExpenseShares();
	const participants = residents.filter((r) => r.active && (!group || groups.find((g) => g.id === group)?.members.includes(r.id)));
	const expenses = (query.data ?? []).filter((e) => filter === "all" || e.status === filter);
	const editor = (shared) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: shared ? "Record shared expense" : "Submit reimbursement claim",
		trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: shared ? "default" : "outline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), shared ? "Shared expense" : "Submit claim"]
		}),
		onSave: async (d) => {
			const amount = toCents(text(d, "amount"));
			if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter a positive amount");
			const file = upload(d);
			const receipt_media_id = file ? await uploadFile("receipts", file) : null;
			const receipt_hash = file ? await fileHash(file) : null;
			const title = text(d, "title");
			if (title.length > 120) throw new Error("Keep the title within 120 characters");
			if (shared) {
				const selected = d.getAll("participants[]").map(String);
				const customShares = custom ? Object.fromEntries(selected.map((id) => [id, toCents(text(d, "share_" + id))])) : null;
				if (customShares && Object.values(customShares).reduce((a, b) => a + b, 0) !== amount) throw new Error("Custom shares must add up to the expense total");
				await recordSharedExpense(d, {
					title,
					amountCents: amount,
					participants: selected,
					customShares,
					group,
					receiptId: receipt_media_id,
					receiptHash: receipt_hash
				});
			} else {
				if (!me?.resident) throw new Error("Your resident account is not linked");
				await submitClaim(d, {
					title,
					amountCents: amount,
					group: text(d, "group") || "",
					payerResidentId: me.resident.id,
					receiptId: receipt_media_id,
					receiptHash: receipt_hash
				});
			}
			await refresh();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Title",
				name: "title",
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Amount (EUR)",
					name: "amount",
					type: "number",
					required: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Date",
					name: "date",
					type: "date",
					value: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Category",
				name: "category",
				value: "general",
				options: [
					"general",
					"groceries",
					"utilities",
					"supplies",
					"repairs",
					"other"
				].map((s) => ({
					id: s,
					name: s
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
				label: "Description",
				name: "description"
			}),
			shared ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Group",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "h-9 rounded-md border bg-background px-3",
						value: group,
						onChange: (e) => setGroup(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Whole flat"
						}), groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: g.id,
							children: g.name
						}, g.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: custom,
						onChange: (e) => setCustom(e.target.checked)
					}), "Custom shares"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-2 text-sm font-medium",
						children: "Participants"
					}), participants.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								name: "participants[]",
								value: r.id,
								defaultChecked: true
							}), r.display_name]
						}), custom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": r.display_name + " share",
							name: "share_" + r.id,
							type: "number",
							step: "0.01",
							min: "0",
							defaultValue: "0",
							className: "h-9 w-24 rounded-md border bg-background px-2"
						})]
					}, r.id))]
				}, group)
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "Group",
				name: "group",
				options: groups.filter((g) => g.members.includes(me?.resident?.id ?? "")).map((g) => ({
					id: g.id,
					name: g.name
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileField, { label: "Receipt" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Expenses",
			sub: "Shared costs and reimbursements",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [me?.isAdmin && editor(true), editor(false)]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex flex-wrap gap-2",
			children: [
				"all",
				"pending",
				"approved",
				"rejected",
				"voided"
			].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: filter === s ? "default" : "outline",
				onClick: () => setFilter(s),
				className: "capitalize",
				children: s
			}, s))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y border-y",
			children: expenses.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold break-words",
								children: e.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									e.expense_date,
									" · ",
									e.category,
									" ·",
									" ",
									e.kind === "claim" ? "Claim by " + (residents.find((r) => r.id === e.payer_resident_id)?.display_name ?? "Resident") : groups.find((g) => g.id === e.group_id)?.name ?? "Whole flat"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shrink-0 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg font-bold",
								children: eur(e.amount_cents)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: e.status })]
						})]
					}),
					e.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm whitespace-pre-wrap break-words",
						children: e.description
					}),
					e.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground break-words",
						children: e.notes
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground",
						children: shares.data?.filter((s) => s.expense_id === e.id).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							residents.find((r) => r.id === s.resident_id)?.display_name,
							":",
							" ",
							eur(s.amount_cents)
						] }, s.id))
					}),
					e.review_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm break-words",
						children: ["Review: ", e.review_note]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							e.receipt_media_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => openFile("receipts", e.receipt_media_id ?? ""),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}), "Receipt"]
							}),
							me?.isAdmin && e.status === "pending" && e.created_by !== me.user.id && [true, false].map((approve) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
								title: approve ? "Approve claim" : "Reject claim",
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: approve ? "default" : "outline",
									size: "sm",
									children: [approve ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), approve ? "Approve" : "Reject"]
								}),
								onSave: async (d) => {
									await reviewClaim(e.id, approve, text(d, "notes"));
									await refresh();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Review note",
									required: !approve
								})
							}, String(approve))),
							me?.isAdmin && e.status === "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
								title: "Void expense",
								destructive: true,
								trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									children: "Void"
								}),
								onSave: async (d) => {
									await voidExpense(e.id, text(d, "notes"));
									await refresh();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
									label: "Reason",
									required: true
								})
							})
						]
					})
				]
			}, e.id))
		}),
		!query.isPending && !expenses.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No expenses in this view." })
	] });
}
//#endregion
export { Expenses as component };
