import { r as __toESM } from "../_runtime.mjs";
import { W as recordPayment, t as addAdjustment } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { I as Download } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor } from "./Forms-Cipd7J0Q.mjs";
import { i as Stat, n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, a as toCents, c as useBalances, g as useMe, h as useLedger, t as eur, v as useResidents } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/balance-D8K_wHLx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Balance() {
	const { data: me } = useMe();
	const { data: residents = [] } = useResidents();
	const { data: balances = [] } = useBalances();
	const [selected, setSelected] = (0, import_react.useState)("");
	const id = me?.isAdmin && selected ? selected : me?.resident?.id;
	const query = useLedger(id);
	const entries = query.data ?? [];
	const bal = balances.find((b) => b.resident_id === id);
	const refresh = useRefresh();
	function exportCsv() {
		const csv = "Date,Type,Note,EUR\n" + entries.map((e) => [
			e.created_at,
			e.kind,
			e.note ?? "",
			(e.amount_cents / 100).toFixed(2)
		].map((v) => "\"" + String(v).replaceAll("\"", "\"\"") + "\"").join(",")).join("\n");
		const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = "flatmate-ledger.csv";
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "My Balance",
			sub: residents.find((r) => r.id === id)?.display_name,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: exportCsv,
				disabled: !entries.length,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Export"]
			})
		}),
		me?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mb-5 grid max-w-sm gap-2 text-sm",
			children: ["Resident", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "h-9 rounded-md border bg-background px-3",
				value: selected || me?.resident?.id || "",
				onChange: (e) => setSelected(e.target.value),
				children: residents.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: r.id,
					children: r.display_name
				}, r.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Current balance",
					value: eur(bal?.balance_cents),
					tone: (bal?.balance_cents ?? 0) < 0 ? "bad" : "good"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Approved reimbursements",
					value: eur(bal?.credits_cents)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Payments recorded",
					value: eur(bal?.payments_cents)
				})
			]
		}),
		me?.isAdmin && id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex flex-wrap gap-3",
			children: ["payment", "adjustment"].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
				title: kind === "payment" ? "Record payment" : "Adjust balance",
				trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					children: kind === "payment" ? "Record payment" : "Adjust balance"
				}),
				onSave: async (d) => {
					const amount = toCents(text(d, "amount"));
					if (!Number.isFinite(amount) || amount === 0) throw new Error("Enter a non-zero amount");
					if (kind === "payment") await recordPayment(id, amount, text(d, "reason"));
					else await addAdjustment(id, amount, text(d, "reason"));
					await refresh();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Amount (EUR, signed)",
					name: "amount",
					type: "number",
					required: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
					label: "Reason",
					name: "reason",
					required: true
				})]
			}, kind))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-xl font-semibold",
					children: "Transaction history"
				}),
				id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y border-y",
					children: entries.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium break-words",
								children: e.note ?? e.kind.replaceAll("_", " ")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									new Date(e.created_at).toLocaleDateString(),
									" · ",
									e.kind.replaceAll("_", " ")
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "shrink-0 " + (e.amount_cents < 0 ? "text-destructive" : "text-success"),
							children: eur(e.amount_cents)
						})]
					}, e.id))
				}),
				!entries.length && !query.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No transactions yet." })
			]
		})
	] });
}
//#endregion
export { Balance as component };
