//#region node_modules/.nitro/vite/services/ssr/assets/portal-permissions-Yq28ENt1.js
var portalPermissions = [
	{
		id: "household.manage",
		name: "Manage groups, rooms and washroom access"
	},
	{
		id: "issues.manage",
		name: "Assign and resolve issues"
	},
	{
		id: "audit.read",
		name: "Read audit history"
	}
];
function canManage(isAdmin, permissions, permission) {
	return isAdmin || permissions.includes(permission);
}
//#endregion
export { portalPermissions as n, canManage as t };
