import { n as api, r as mediaUrl, t as ApiError } from "./api-Bz4c_dXI.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/flat-prlcA8Ar.js
var eur = (cents) => new Intl.NumberFormat("de-AT", {
	style: "currency",
	currency: "EUR"
}).format((cents ?? 0) / 100);
var toCents = (v) => Math.round(parseFloat(v.replace(",", ".")) * 100);
function useMe() {
	return useQuery({
		queryKey: ["me"],
		queryFn: async () => {
			try {
				return await api.get("/auth/me");
			} catch (error) {
				if (error instanceof ApiError && error.status === 401) return null;
				throw error;
			}
		}
	});
}
var useSpaces = () => useQuery({
	queryKey: ["spaces"],
	queryFn: () => api.get("/spaces")
});
var useResidents = () => useQuery({
	queryKey: ["residents"],
	queryFn: () => api.get("/residents")
});
var useGroups = () => useQuery({
	queryKey: ["groups"],
	queryFn: () => api.get("/groups")
});
var useWashroomAccess = () => useQuery({
	queryKey: ["washroom_access"],
	queryFn: () => api.get("/washroom-access")
});
var useBalances = () => useQuery({
	queryKey: ["balances"],
	queryFn: () => api.get("/balances")
});
var useExpenses = () => useQuery({
	queryKey: ["expenses"],
	queryFn: () => api.get("/expenses")
});
var useExpenseShares = () => useQuery({
	queryKey: ["expense_shares"],
	queryFn: () => api.get("/expense-shares")
});
var useChores = () => useQuery({
	queryKey: ["chores"],
	queryFn: () => api.get("/chores")
});
var useChoreEvents = () => useQuery({
	queryKey: ["chore_events"],
	queryFn: () => api.get("/chore-events")
});
var useIssues = () => useQuery({
	queryKey: ["issues"],
	queryFn: () => api.get("/issues")
});
var useLedger = (residentId) => useQuery({
	queryKey: ["ledger", residentId],
	enabled: !!residentId,
	queryFn: () => api.get(`/ledger/${residentId}`)
});
var useAudit = () => useQuery({
	queryKey: ["audit"],
	queryFn: () => api.get("/audit")
});
function useRefresh() {
	const qc = useQueryClient();
	return () => qc.invalidateQueries();
}
/** Uploads media into the backend media library and returns the new asset id (files live on disk, rows in media_assets). */
async function uploadFile(bucket, file) {
	if (file.size > 10485760) throw new Error("Please choose a file smaller than 10 MB");
	const form = new FormData();
	form.append("file", file);
	let asset;
	if (bucket === "receipts" || bucket === "photos") asset = await api.post(`/media?bucket=${bucket}`, form);
	else throw new Error("Use the media library for website graphics");
	return asset.id;
}
async function fileHash(file) {
	const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
	return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
/** Receipts/photos stream through authenticated API routes (same cookie, no signed URLs needed). */
function openFile(_bucket, mediaId) {
	window.open(mediaUrl(mediaId), "_blank", "noopener");
}
function nameOf(residents, id) {
	if (!id) return "—";
	return residents?.find((r) => r.id === id)?.display_name ?? "Unknown";
}
//#endregion
export { useRefresh as _, toCents as a, useWashroomAccess as b, useBalances as c, useExpenseShares as d, useExpenses as f, useMe as g, useLedger as h, openFile as i, useChoreEvents as l, useIssues as m, fileHash as n, uploadFile as o, useGroups as p, nameOf as r, useAudit as s, eur as t, useChores as u, useResidents as v, useSpaces as y };
