import { P as listMedia } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as DataState } from "./Forms-Cipd7J0Q.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { v as useResidents } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CmsBits-Beh0tpR5.js
var import_jsx_runtime = require_jsx_runtime();
/**
* UTC 'YYYY-MM-DD HH:MM:SS' (backend DATETIME) → value for <input type="datetime-local">
* in the browser's timezone (reversed by toUtc on submit).
*/
function utcToLocal(value) {
	if (!value) return "";
	const normalized = value.includes("T") ? value : value.replace(" ", "T") + "Z";
	const date = new Date(normalized);
	if (Number.isNaN(date.getTime())) return "";
	return (/* @__PURE__ */ new Date(date.getTime() - date.getTimezoneOffset() * 6e4)).toISOString().slice(0, 16);
}
/** datetime-local value → ISO offset string the PHP layer normalises to UTC DATETIME. */
function toUtc(value) {
	if (!value) return void 0;
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) throw new Error("Please use the date/time picker");
	return date.toISOString().slice(0, 19) + "+00:00";
}
/** Formats a stored UTC datetime for on-page display. */
function formatUtc(value) {
	if (!value) return "—";
	return (/* @__PURE__ */ new Date(value.includes("T") ? value.replace(" ", "T") + "Z" : value.replace(" ", "T") + "Z")).toLocaleString(void 0, {
		dateStyle: "medium",
		timeStyle: "short"
	});
}
/** Select of media-library assets (used for covers/section graphics). */
function MediaSelect({ label, name, value, required = false }) {
	const media = useQuery({
		queryKey: ["media-all"],
		queryFn: () => listMedia({ per_page: 200 })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2 text-sm font-medium",
		children: [label, media.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground",
			children: "Loading media library…"
		}) : media.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: media }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			name,
			defaultValue: value ?? "",
			required,
			className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "—"
			}), (media.data?.items ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
				value: m.id,
				children: [
					(m.alt_text ?? m.original_name ?? m.file_path).slice(0, 60),
					" (",
					m.bucket,
					")"
				]
			}, m.id))]
		})]
	});
}
/** Resident picker for shift planning. */
function ResidentSelect({ label, name, value, required = false }) {
	const { data: residents = [] } = useResidents();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2 text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			name,
			defaultValue: value ?? "",
			required,
			className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "—"
			}), residents.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: r.id,
				children: r.display_name
			}, r.id))]
		})]
	});
}
var eurCms = (cents) => new Intl.NumberFormat("de-AT", {
	style: "currency",
	currency: "EUR"
}).format((cents ?? 0) / 100);
//#endregion
export { toUtc as a, formatUtc as i, ResidentSelect as n, utcToLocal as o, eurCms as r, MediaSelect as t };
