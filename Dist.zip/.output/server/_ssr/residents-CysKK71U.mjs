import { f as createResident, vt as updateResident } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { o as Users, x as Pencil, y as Plus } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, r as Editor, s as Status, t as Choice } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { _ as useRefresh, b as useWashroomAccess, g as useMe, p as useGroups, v as useResidents, y as useSpaces } from "./flat-prlcA8Ar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/residents-CysKK71U.js
var import_jsx_runtime = require_jsx_runtime();
function Residents() {
	const query = useResidents();
	const residents = query.data ?? [];
	const { data: spaces = [] } = useSpaces();
	const { data: groups = [] } = useGroups();
	const { data: access = [] } = useWashroomAccess();
	const { data: me } = useMe();
	const refresh = useRefresh();
	const rooms = spaces.filter((s) => s.kind === "bedroom").map((s) => ({
		id: s.id,
		name: s.name
	}));
	const edit = (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: r ? "Edit resident" : "Add resident",
		trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: r ? "outline" : "default",
			size: r ? "icon" : "default",
			"aria-label": r ? "Edit " + r.display_name : void 0,
			children: r ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add resident"] })
		}),
		onSave: async (d) => {
			const values = {
				display_name: text(d, "name"),
				phone: text(d, "phone") || null,
				...me?.isAdmin ? {
					email: text(d, "email") || null,
					room_id: text(d, "room") || null,
					active: d.get("active") === "on"
				} : {}
			};
			if (r) await updateResident(r.id, values);
			else await createResident(values);
			await refresh();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Name",
				name: "name",
				value: r?.display_name,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Phone",
				name: "phone",
				value: r?.phone ?? ""
			}),
			me?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					label: "Email",
					name: "email",
					type: "email",
					value: r?.email ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Room",
					name: "room",
					value: r?.room_id ?? "",
					options: rooms
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "active",
						type: "checkbox",
						defaultChecked: r?.active ?? true
					}), "Active resident"]
				})
			] })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Residents",
			sub: `${residents.filter((r) => r.active).length} people at home`,
			action: me?.isAdmin ? edit() : void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: residents.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-full bg-secondary font-display text-lg font-bold",
								children: r.display_name.slice(0, 1)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold break-words",
								children: r.display_name
							})]
						}), (me?.isAdmin || r.user_id === me?.user.id) && edit(r)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: r.active ? "active" : "inactive" }),
							r.is_sample && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: "sample" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted-foreground",
								children: spaces.find((s) => s.id === r.room_id)?.name ?? "Room not assigned"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-1 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "break-all",
								children: r.email ?? "No email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: r.phone ?? "No phone" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: access.filter((a) => a.bedroom_id === r.room_id).map((a) => spaces.find((s) => s.id === a.washroom_id)?.name).filter(Boolean).join(" · ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: groups.filter((g) => g.members.includes(r.id)).map((g) => g.name).join(" · ")
							})
						]
					})
				]
			}, r.id))
		}),
		!query.isPending && !residents.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No residents yet." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mb-4 flex items-center gap-2 text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-5 w-5" }), "Household groups"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: g.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: g.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: residents.filter((r) => g.members.includes(r.id)).map((r) => r.display_name).join(", ") || "No members"
						})
					]
				}, g.id))
			})]
		})
	] });
}
//#endregion
export { Residents as component };
