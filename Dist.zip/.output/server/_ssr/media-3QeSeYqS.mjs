import { r as __toESM } from "../_runtime.mjs";
import { i as openMedia, r as mediaUrl } from "./api-Bz4c_dXI.mjs";
import { P as listMedia, _ as deleteMedia, _t as updateMediaMeta, bt as uploadMedia, q as replaceMedia } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { _ as RefreshCcw, c as Upload, g as Search, u as Trash2 } from "../_libs/lucide-react.mjs";
import { a as FileField, c as TextField, l as text, n as DataState, o as Notes, r as Editor, u as upload } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader, t as Empty } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { i as formatUtc } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-3QeSeYqS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MediaLibrary() {
	const me = useMe();
	const qc = useQueryClient();
	const [bucket, setBucket] = (0, import_react.useState)("");
	const [q, setQ] = (0, import_react.useState)("");
	const [search, setSearch] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const refresh = () => qc.invalidateQueries({ queryKey: ["media"] });
	const media = useQuery({
		queryKey: [
			"media",
			bucket,
			search,
			page
		],
		queryFn: () => listMedia({
			bucket: bucket || void 0,
			q: search || void 0,
			page,
			per_page: 24
		})
	});
	if (!me.data?.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-destructive",
		children: "Only administrators can manage the media library."
	});
	const pages = media.data ? Math.max(1, Math.ceil(media.data.total / media.data.per_page)) : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Media library",
				sub: "Images live on the server disk (backend/uploads); receipts stay private, website graphics are public.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
					title: "Upload image",
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }), "Upload image"] }),
					onSave: async (d) => {
						const file = upload(d);
						if (!file) throw new Error("Choose an image (JPG, PNG, WebP, max 10 MB)");
						const asset = await uploadMedia("media", file);
						const alt = text(d, "alt");
						const caption = text(d, "caption");
						if (alt || caption) await updateMediaMeta(asset.id, {
							alt_text: alt || null,
							caption: caption || null
						});
						await refresh();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileField, {
							label: "Image (JPG/PNG/WebP)",
							name: "file"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Alt text",
							name: "alt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Caption",
							name: "caption"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: bucket,
						onChange: (e) => {
							setBucket(e.target.value);
							setPage(1);
							qc.invalidateQueries({ queryKey: ["media"] });
						},
						className: "h-9 w-32 rounded-md border bg-background px-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "All kinds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "media",
								children: "Graphics"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "receipts",
								children: "Receipts"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "photos",
								children: "Photos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "social",
								children: "Social"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "w-56",
						placeholder: "Search file name, alt text…",
						value: q,
						onChange: (e) => setQ(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter") {
								setSearch(q);
								setPage(1);
							}
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => {
							setSearch(q);
							setPage(1);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }), "Search"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: media }),
			media.data && media.data.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No files yet — upload the first graphic." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: (media.data?.items ?? []).map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetCard, {
					asset,
					onChanged: refresh
				}, asset.id))
			}),
			pages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-center gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: page <= 1,
						onClick: () => setPage(page - 1),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Page ",
						page,
						" of ",
						pages
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: page >= pages,
						onClick: () => setPage(page + 1),
						children: "Next"
					})
				]
			})
		]
	});
}
function AssetCard({ asset, onChanged }) {
	const isImage = (asset.mime_type ?? "").startsWith("image/");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-xl border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => openMedia(asset.id),
				"aria-label": "View " + (asset.alt_text ?? asset.original_name ?? "media"),
				className: "block aspect-square w-full overflow-hidden rounded-lg border bg-muted",
				children: isImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: mediaUrl(asset.id),
					alt: asset.alt_text ?? "",
					className: "h-full w-full object-cover",
					loading: "lazy"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-full w-full place-items-center text-xs text-muted-foreground",
					children: asset.mime_type || "file"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "mt-2 space-y-1 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium text-foreground",
					children: asset.alt_text ?? asset.original_name ?? asset.file_path
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					asset.bucket,
					" · ",
					asset.width ? `${asset.width}×${asset.height} · ` : "",
					formatUtc(asset.created_at)
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
						title: "Replace file",
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCcw, { className: "h-4 w-4" }), "Replace"]
						}),
						onSave: async (d) => {
							const file = upload(d);
							if (!file) throw new Error("Choose a replacement image");
							await replaceMedia(asset.id, file);
							await onChanged();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileField, {
							label: "New image",
							name: "file"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
						title: "Edit details",
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							children: "Details"
						}),
						onSave: async (d) => {
							await updateMediaMeta(asset.id, {
								alt_text: text(d, "alt_text") || null,
								caption: text(d, "caption") || null
							});
							await onChanged();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Alt text",
							name: "alt_text",
							value: asset.alt_text ?? ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
							label: "Caption",
							name: "caption",
							value: asset.caption ?? ""
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
						title: "Delete file",
						destructive: true,
						trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "text-destructive",
							"aria-label": "Delete " + (asset.alt_text ?? "file"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), "Delete"]
						}),
						onSave: async () => {
							await deleteMedia(asset.id);
							await onChanged();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"Pages that reference this file will lose it. Delete “",
								asset.alt_text ?? asset.original_name ?? asset.file_path,
								"”?"
							]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { MediaLibrary as component };
