import { r as __toESM } from "../_runtime.mjs";
import { K as reorderSections, dt as siteSettings, it as saveSiteSettings, rt as saveSiteSection, ut as siteContent } from "./flat-actions-CfxSy5Of.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { G as ArrowUp, N as Eye, P as EyeOff, h as Settings, q as ArrowDown, x as Pencil } from "../_libs/lucide-react.mjs";
import { c as TextField, l as text, n as DataState, o as Notes, r as Editor } from "./Forms-Cipd7J0Q.mjs";
import { n as PageHeader } from "./Page-CAF0l6GE.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as useMe } from "./flat-prlcA8Ar.mjs";
import { t as MediaSelect } from "./CmsBits-Beh0tpR5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/content-_Y3WiSR2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AREA_LABELS = {
	home: "Homepage",
	nav: "Navigation",
	footer: "Footer",
	donations: "Donation area"
};
var EMPTY_TEXT = {
	heading: null,
	subheading: null,
	body: null
};
function translationsLookup(rows) {
	const map = {};
	for (const row of rows) {
		map[row.section_code] ??= {};
		map[row.section_code][row.locale] = row;
	}
	return map;
}
function Content() {
	const me = useMe();
	const qc = useQueryClient();
	const query = useQuery({
		queryKey: ["site-content"],
		queryFn: siteContent
	});
	const settingsQuery = useQuery({
		queryKey: ["site-settings"],
		queryFn: siteSettings
	});
	const refresh = async () => {
		await Promise.all([
			qc.invalidateQueries({ queryKey: ["site-content"] }),
			qc.invalidateQueries({ queryKey: ["site-settings"] }),
			qc.invalidateQueries({ queryKey: ["public-homepage"] })
		]);
	};
	const translations = translationsLookup(query.data?.translations ?? []);
	const sections = query.data?.sections ?? [];
	const areas = [
		"home",
		"nav",
		"footer",
		"donations"
	];
	if (!me.data?.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-destructive",
		children: "Only administrators can edit the homepage content."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Homepage content",
				sub: "What visitors read on the public landing page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query }),
			areas.map((area) => {
				const rows = sections.filter((s) => s.area === area).sort((a, b) => a.sort - b.sort);
				if (!rows.length) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-lg font-semibold",
						children: AREA_LABELS[area]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3",
						children: rows.map((section, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionRow, {
							section,
							index,
							siblings: rows.map((s) => s.code),
							tr: translations[section.code] ?? {},
							onChanged: refresh
						}, section.code))
					})]
				}, area);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 text-lg font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-5 w-5" }), " Site settings"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataState, { query: settingsQuery }),
					settingsQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsEditor, {
						initial: Object.fromEntries(settingsQuery.data.map((r) => [r.setting_key, r.setting_value])),
						onSaved: refresh
					})
				]
			})
		]
	});
}
function SectionRow({ section, tr, index, siblings, onChanged }) {
	const en = tr["en"] ?? EMPTY_TEXT;
	const de = tr["de"] ?? EMPTY_TEXT;
	const editor = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Editor, {
		title: "Edit section",
		trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "icon",
			variant: "outline",
			"aria-label": "Edit section " + section.code,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
		}),
		onSave: async (d) => {
			const body = {
				icon: text(d, "icon") || null,
				media_id: text(d, "media_id") || null,
				media_position: text(d, "media_position") || null,
				cta_label: text(d, "cta_label") || null,
				cta_href: text(d, "cta_href") || null,
				cta2_label: text(d, "cta2_label") || null,
				cta2_href: text(d, "cta2_href") || null,
				en: {
					heading: text(d, "en_heading"),
					subheading: text(d, "en_subheading"),
					body: text(d, "en_body")
				},
				de: {
					heading: text(d, "de_heading"),
					subheading: text(d, "de_subheading"),
					body: text(d, "de_body")
				}
			};
			await saveSiteSection(section.code, body);
			await onChanged();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Icon (lucide name, e.g. receipt)",
				name: "icon",
				value: section.icon ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaSelect, {
				label: "Image",
				name: "media_id",
				value: section.media_id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Image position", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					name: "media_position",
					defaultValue: section.media_position ?? "",
					className: "h-9 w-full rounded-md border bg-background px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), [
						"cover",
						"left",
						"right",
						"center",
						"background"
					].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p,
						children: p
					}, p))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Button label",
						name: "cta_label",
						value: section.cta_label ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Button target (/auth)",
						name: "cta_href",
						value: section.cta_href ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Second button label",
						name: "cta2_label",
						value: section.cta2_label ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Second button target",
						name: "cta2_href",
						value: section.cta2_href ?? ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 rounded-lg border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase text-muted-foreground",
						children: "English"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Heading",
						name: "en_heading",
						value: en.heading ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Subheading",
						name: "en_subheading",
						value: en.subheading ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
						label: "Text",
						name: "en_body",
						value: en.body ?? ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 rounded-lg border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase text-muted-foreground",
						children: "Deutsch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Titel",
						name: "de_heading",
						value: de.heading ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Untertitel",
						name: "de_subheading",
						value: de.subheading ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {
						label: "Text",
						name: "de_body",
						value: de.body ?? ""
					})
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-wrap items-start gap-3 rounded-xl border bg-card p-4" + (section.visible ? "" : " opacity-60"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					disabled: index === 0,
					"aria-label": "Move up",
					onClick: () => runReorder(swapAt(siblings, index, index - 1), section.area, onChanged),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					disabled: index === siblings.length - 1,
					"aria-label": "Move down",
					onClick: () => runReorder(swapAt(siblings, index, index + 1), section.area, onChanged),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: section.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground",
							children: section.kind
						}),
						section.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-success/10 px-2 py-1 text-xs text-success",
							children: "visible"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-secondary px-2 py-1 text-xs text-muted-foreground",
							children: "hidden"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 break-words text-sm text-muted-foreground",
					children: en.heading ?? en.subheading ?? en.body ?? "(no English copy)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: async () => {
						await saveSiteSection(section.code, { visible: !section.visible });
						await onChanged();
					},
					children: section.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }), "Hide"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" }), "Show"] })
				}), editor]
			})
		]
	});
}
async function runReorder(codes, area, onChanged) {
	await reorderSections(codes, area);
	await onChanged();
}
/** Reorders one area's codes by swapping the section at `index` with its new neighbour. */
function swapAt(codes, index, target) {
	const out = [...codes];
	const moved = out[target];
	out[target] = out[index];
	out[index] = moved;
	return out;
}
function SettingsEditor({ initial, onSaved }) {
	const [saving, setSaving] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-4 grid gap-4 sm:grid-cols-2",
		onSubmit: async (e) => {
			e.preventDefault();
			const d = new FormData(e.currentTarget);
			setSaving(true);
			try {
				await saveSiteSettings({
					site_name: text(d, "site_name") || "FlatMate Hub",
					default_locale: text(d, "default_locale") || "en",
					social_instagram_url: text(d, "social_instagram_url"),
					donations_public: d.get("donations_public") === "on" ? "1" : "0",
					donations_goal: text(d, "donations_goal"),
					donations_account: text(d, "donations_account"),
					donations_instructions: text(d, "donations_instructions")
				});
				await onSaved();
			} catch (err) {
				throw err;
			} finally {
				setSaving(false);
			}
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Site name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "site_name",
					defaultValue: initial.site_name ?? "",
					className: "h-9 rounded-md border bg-background px-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Default language (en/de)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "default_locale",
					defaultValue: initial.default_locale ?? "en",
					className: "h-9 rounded-md border bg-background px-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Instagram URL", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "social_instagram_url",
					defaultValue: initial.social_instagram_url ?? "",
					className: "h-9 rounded-md border bg-background px-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "grid items-center gap-2 text-sm font-medium",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						name: "donations_public",
						defaultChecked: initial.donations_public === "1"
					}), " Show donation area publicly"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Donation goal (EUR, optional)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "donations_goal",
					type: "number",
					step: "0.01",
					min: "0",
					defaultValue: initial.donations_goal ?? "",
					className: "h-9 rounded-md border bg-background px-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Donation account details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "donations_account",
					defaultValue: initial.donations_account ?? "",
					className: "h-9 rounded-md border bg-background px-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium sm:col-span-2",
				children: ["Donation instructions shown on the homepage", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "donations_instructions",
					defaultValue: initial.donations_instructions ?? "",
					rows: 2,
					maxLength: 2e3,
					className: "w-full rounded-md border bg-background p-3 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: saving,
				children: "Save settings"
			}) })
		]
	});
}
//#endregion
export { Content as component };
