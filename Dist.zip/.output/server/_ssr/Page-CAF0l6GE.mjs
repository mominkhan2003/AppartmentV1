import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Page-CAF0l6GE.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ title, sub, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-bold",
			children: title
		}), sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-muted-foreground",
			children: sub
		})] }), action]
	});
}
function Panel({ title, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border bg-card p-5 " + className,
		children: [title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-lg font-semibold",
			children: title
		}), children]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-display text-2xl font-bold " + (tone === "good" ? "text-success" : tone === "bad" ? "text-destructive" : ""),
			children: value
		})]
	});
}
var Empty = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	className: "py-6 text-center text-sm text-muted-foreground",
	children
});
var run = async (fn, ok, done) => {
	const { toast } = await import("../_libs/sonner.mjs").then((n) => n.n);
	try {
		await fn();
		toast.success(ok);
		done?.();
	} catch (e) {
		toast.error(e.message);
	}
};
//#endregion
export { run as a, Stat as i, PageHeader as n, Panel as r, Empty as t };
