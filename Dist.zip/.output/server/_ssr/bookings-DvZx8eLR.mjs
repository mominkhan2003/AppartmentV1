import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as HubPage } from "./HubPage-ByHu0c7G.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookings-DvZx8eLR.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubPage, { kind: "bookings" });
}
//#endregion
export { Page as component };
