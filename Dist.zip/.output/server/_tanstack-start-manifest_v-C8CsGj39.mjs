//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C8CsGj39.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/reset-password"
		],
		preloads: ["/assets/index-BsWgxSku.js", "/assets/react-COMFa4n5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BsWgxSku.js"
		} }]
	},
	"/": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-7YzXeP7k.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/house-DDKvW2WR.js",
			"/assets/wrench-BACC6QdI.js",
			"/assets/button-Cy0XUnF1.js",
			"/assets/input-dQK-4EQx.js"
		]
	},
	"/_authenticated": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/account",
			"/_authenticated/admin",
			"/_authenticated/balance",
			"/_authenticated/bookings",
			"/_authenticated/cleaning",
			"/_authenticated/contacts",
			"/_authenticated/content",
			"/_authenticated/dashboard",
			"/_authenticated/documents",
			"/_authenticated/donations",
			"/_authenticated/events",
			"/_authenticated/events-plan",
			"/_authenticated/expenses",
			"/_authenticated/inventory",
			"/_authenticated/issues",
			"/_authenticated/lost-found",
			"/_authenticated/media",
			"/_authenticated/notices",
			"/_authenticated/notifications",
			"/_authenticated/polls",
			"/_authenticated/residents",
			"/_authenticated/rules",
			"/_authenticated/shopping",
			"/_authenticated/studio"
		],
		preloads: [
			"/assets/route-ByQBUQ9t.js",
			"/assets/createLucideIcon-DCo7j3Vq.js",
			"/assets/hub-xtocUz_W.js",
			"/assets/house-DDKvW2WR.js",
			"/assets/wrench-BACC6QdI.js",
			"/assets/user-round-Db7wSiDF.js",
			"/assets/users-q-xR6rLz.js",
			"/assets/button-Cy0XUnF1.js",
			"/assets/flat-Dr5aLnNy.js"
		]
	},
	"/auth": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DuKvA23W.js",
			"/assets/house-DDKvW2WR.js",
			"/assets/button-Cy0XUnF1.js",
			"/assets/input-dQK-4EQx.js",
			"/assets/label-OrKj5uuH.js"
		]
	},
	"/reset-password": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CP57ktXi.js",
			"/assets/button-Cy0XUnF1.js",
			"/assets/input-dQK-4EQx.js",
			"/assets/label-OrKj5uuH.js"
		]
	},
	"/_authenticated/account": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-XMtAT3kU.js",
			"/assets/mail-BPfz_Xqo.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-ybTTKSQx.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/pencil-BCEwK4iS.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/trash-2-BE0TwpST.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/portal-permissions-D7SIglOm.js"
		]
	},
	"/_authenticated/balance": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/balance.tsx",
		children: void 0,
		preloads: [
			"/assets/balance-Ybc4UKd3.js",
			"/assets/download-0_8-Edho.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/bookings": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/bookings.tsx",
		children: void 0,
		preloads: ["/assets/bookings-DsWxeYlA.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/cleaning": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/cleaning.tsx",
		children: void 0,
		preloads: [
			"/assets/cleaning-hk1Zj9am.js",
			"/assets/check-Cu5Pci7B.js",
			"/assets/image-Crnenqop.js",
			"/assets/pencil-BCEwK4iS.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/contacts": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/contacts.tsx",
		children: void 0,
		preloads: ["/assets/contacts-DNbhDCMO.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/content": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/content.tsx",
		children: void 0,
		preloads: [
			"/assets/content-Cdn6FCYR.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/pencil-BCEwK4iS.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BMD3Fgee.js",
			"/assets/utils-4jUIYOBc.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: ["/assets/documents-DmGlSbS7.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/donations": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/donations.tsx",
		children: void 0,
		preloads: [
			"/assets/donations-n0eslWQi.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/trash-2-BE0TwpST.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	},
	"/_authenticated/events": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/events.tsx",
		children: void 0,
		preloads: ["/assets/events-DbP4ktjT.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/events-plan": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/events-plan.tsx",
		children: void 0,
		preloads: [
			"/assets/events-plan-Lnr4NXtw.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/calendar-days-i7SH472A.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/trash-2-BE0TwpST.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	},
	"/_authenticated/expenses": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-D8yHI_gC.js",
			"/assets/check-Cu5Pci7B.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/inventory": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/inventory.tsx",
		children: void 0,
		preloads: ["/assets/inventory-Bnqw0gd_.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/issues": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/issues.tsx",
		children: void 0,
		preloads: [
			"/assets/issues-CQHcMURu.js",
			"/assets/image-Crnenqop.js",
			"/assets/pencil-BCEwK4iS.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/portal-permissions-D7SIglOm.js"
		]
	},
	"/_authenticated/lost-found": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/lost-found.tsx",
		children: void 0,
		preloads: ["/assets/lost-found-DaajfSqn.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/media": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/media.tsx",
		children: void 0,
		preloads: [
			"/assets/media-BpZmnJZ4.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/search-D7kTqDS6.js",
			"/assets/trash-2-BE0TwpST.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/input-dQK-4EQx.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	},
	"/_authenticated/notices": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/notices.tsx",
		children: void 0,
		preloads: ["/assets/notices-CY8kM165.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/notifications": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-Ddtd1dx-.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/check-check-C-NG-O-w.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	},
	"/_authenticated/polls": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/polls.tsx",
		children: void 0,
		preloads: ["/assets/polls-DpBsF_IV.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/residents": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/residents.tsx",
		children: void 0,
		preloads: [
			"/assets/residents-BFYDJctq.js",
			"/assets/pencil-BCEwK4iS.js",
			"/assets/plus-Clqs3nAE.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js"
		]
	},
	"/_authenticated/rules": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/rules.tsx",
		children: void 0,
		preloads: ["/assets/rules-BhiWokm-.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/shopping": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/shopping.tsx",
		children: void 0,
		preloads: ["/assets/shopping-FxPTwJ9c.js", "/assets/HubPage-Cz-3kQS1.js"]
	},
	"/_authenticated/studio": {
		filePath: "G:/University Related Things/AppartmentV1/src/routes/_authenticated/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-BiaioRMr.js",
			"/assets/useQuery-BdPGL1oV.js",
			"/assets/download-0_8-Edho.js",
			"/assets/trash-2-BE0TwpST.js",
			"/assets/Forms-dLB3cuB_.js",
			"/assets/Page-CIQhHxc4.js",
			"/assets/CmsBits-B-LIVsgy.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
