globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/account-XMtAT3kU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d49-O+/SERMr9tit6kSDncmidfDh3l8\"",
		"mtime": "2026-10-19T11:12:23.319Z",
		"size": 3401,
		"path": "../public/assets/account-XMtAT3kU.js"
	},
	"/assets/admin-ybTTKSQx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b02-T55YOQ8cNZcXIOxxr7pRnvuZoP0\"",
		"mtime": "2026-10-19T11:12:23.320Z",
		"size": 11010,
		"path": "../public/assets/admin-ybTTKSQx.js"
	},
	"/assets/auth-DuKvA23W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aef-hAymcUGDzM5F6DPs3528MfEPQEc\"",
		"mtime": "2026-10-19T11:12:23.321Z",
		"size": 2799,
		"path": "../public/assets/auth-DuKvA23W.js"
	},
	"/assets/balance-Ybc4UKd3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ca8-9dtLeSK2wmlfZ6tnLuqPp87ceC0\"",
		"mtime": "2026-10-19T11:12:23.321Z",
		"size": 3240,
		"path": "../public/assets/balance-Ybc4UKd3.js"
	},
	"/assets/bookings-DsWxeYlA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1-85tpbwcdNyXmVbbjry+5MoRewjA\"",
		"mtime": "2026-10-19T11:12:23.321Z",
		"size": 161,
		"path": "../public/assets/bookings-DsWxeYlA.js"
	},
	"/assets/button-Cy0XUnF1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1363-b4IBCnwKL7idlu33wekSpHuAEEs\"",
		"mtime": "2026-10-19T11:12:23.321Z",
		"size": 4963,
		"path": "../public/assets/button-Cy0XUnF1.js"
	},
	"/assets/calendar-days-i7SH472A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-mZwykAU5nqA0k5dR9+sZrobauM0\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 494,
		"path": "../public/assets/calendar-days-i7SH472A.js"
	},
	"/assets/check-check-C-NG-O-w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-AhzIon7jS6S5xNQJU8dWYOyZRMY\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 179,
		"path": "../public/assets/check-check-C-NG-O-w.js"
	},
	"/assets/check-Cu5Pci7B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-6oro3seFk0gJHzOFzS4hfa1w5qc\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 124,
		"path": "../public/assets/check-Cu5Pci7B.js"
	},
	"/assets/cleaning-hk1Zj9am.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18ac-HqwI1Fh1LU7X+EPiRdnMZxfZOyc\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 6316,
		"path": "../public/assets/cleaning-hk1Zj9am.js"
	},
	"/assets/CmsBits-B-LIVsgy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"778-rcQPVDVgm/3B+ysRGjrzdGAZ0iA\"",
		"mtime": "2026-10-19T11:12:23.303Z",
		"size": 1912,
		"path": "../public/assets/CmsBits-B-LIVsgy.js"
	},
	"/assets/contacts-DNbhDCMO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1-V/eF6QIrGxT2XTLtlpUHfQi1Ss8\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 161,
		"path": "../public/assets/contacts-DNbhDCMO.js"
	},
	"/assets/createLucideIcon-DCo7j3Vq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a0-1gQ7IzjbRFWpDY3CUek13Ejw91I\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 1184,
		"path": "../public/assets/createLucideIcon-DCo7j3Vq.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-10-18T10:43:36.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/content-Cdn6FCYR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26f0-FsOCP/slKIAzXmPc3Ze9svGXVqg\"",
		"mtime": "2026-10-19T11:12:23.325Z",
		"size": 9968,
		"path": "../public/assets/content-Cdn6FCYR.js"
	},
	"/assets/documents-DmGlSbS7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-TSJ9ERZ9AO4MSZ48nw8QLMXaE1M\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 162,
		"path": "../public/assets/documents-DmGlSbS7.js"
	},
	"/assets/donations-n0eslWQi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"312e-qgGg3zkymeLDAhisAdGd+YA5E5M\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 12590,
		"path": "../public/assets/donations-n0eslWQi.js"
	},
	"/assets/download-0_8-Edho.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-ZM3jpR4MRvEX782ppT/i0JxP2CA\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 232,
		"path": "../public/assets/download-0_8-Edho.js"
	},
	"/assets/dashboard-BMD3Fgee.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1591-S5GIUSxm1ryezkDyx7Ffennb+3A\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 5521,
		"path": "../public/assets/dashboard-BMD3Fgee.js"
	},
	"/assets/events-DbP4ktjT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-qQw8L1I+TBQtodKJfIWJuYKvBd0\"",
		"mtime": "2026-10-19T11:12:23.327Z",
		"size": 159,
		"path": "../public/assets/events-DbP4ktjT.js"
	},
	"/assets/events-plan-Lnr4NXtw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b1e-Z0ez5Ebz/wfXVhKaHNIl6JYqkhA\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 11038,
		"path": "../public/assets/events-plan-Lnr4NXtw.js"
	},
	"/assets/expenses-D8yHI_gC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a35-tqUSFcNH0IWST5/bwbGgvyvbi9M\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 6709,
		"path": "../public/assets/expenses-D8yHI_gC.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-18T10:43:36.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/flat-Dr5aLnNy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7d3-lqrZDdwALwPuttHJus+7W2aSjqg\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 2003,
		"path": "../public/assets/flat-Dr5aLnNy.js"
	},
	"/assets/Forms-dLB3cuB_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9cfb-Zk7vQC1S+pM4lTHza+oleZb1cf0\"",
		"mtime": "2026-10-19T11:12:23.303Z",
		"size": 40187,
		"path": "../public/assets/Forms-dLB3cuB_.js"
	},
	"/assets/house-DDKvW2WR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"119-mhqBO0Ymy5kM86uEtQac0tE38gY\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 281,
		"path": "../public/assets/house-DDKvW2WR.js"
	},
	"/assets/HubPage-Cz-3kQS1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d48-cIlIgwJMNLtPweh5ZrPzNxOedW8\"",
		"mtime": "2026-10-19T11:12:23.303Z",
		"size": 11592,
		"path": "../public/assets/HubPage-Cz-3kQS1.js"
	},
	"/assets/hub-xtocUz_W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1612-1Xnt5UkdY1pQGiyflSiKQA3brVs\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 5650,
		"path": "../public/assets/hub-xtocUz_W.js"
	},
	"/assets/image-Crnenqop.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-HPui7mL3UomAFXQawSEJ2g6VfRQ\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 269,
		"path": "../public/assets/image-Crnenqop.js"
	},
	"/assets/input-dQK-4EQx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"284-11TY3NQWtfPzsbnEldQonwbpeNc\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 644,
		"path": "../public/assets/input-dQK-4EQx.js"
	},
	"/assets/inventory-Bnqw0gd_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-RcsmzbtchdyZXrGeMC2fwUTItuI\"",
		"mtime": "2026-10-19T11:12:23.329Z",
		"size": 162,
		"path": "../public/assets/inventory-Bnqw0gd_.js"
	},
	"/assets/issues-CQHcMURu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ece-HZu3o/nauKaygA5AcdngvW4O2mQ\"",
		"mtime": "2026-10-19T11:12:23.331Z",
		"size": 3790,
		"path": "../public/assets/issues-CQHcMURu.js"
	},
	"/assets/lost-found-DaajfSqn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a3-2Q1qEAvNM/YDOz9hKK4ZLUJTzms\"",
		"mtime": "2026-10-19T11:12:23.393Z",
		"size": 163,
		"path": "../public/assets/lost-found-DaajfSqn.js"
	},
	"/assets/label-OrKj5uuH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e9-BkJCaWVdk7Lpus25JHWPzYGOrFM\"",
		"mtime": "2026-10-19T11:12:23.360Z",
		"size": 1257,
		"path": "../public/assets/label-OrKj5uuH.js"
	},
	"/assets/mail-BPfz_Xqo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-nNvPH9No/6vRE79jwQysSAb+p2U\"",
		"mtime": "2026-10-19T11:12:23.395Z",
		"size": 213,
		"path": "../public/assets/mail-BPfz_Xqo.js"
	},
	"/assets/index-BsWgxSku.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6567b-4+OnKFER2KZTuXYPXfk7DDY+QmU\"",
		"mtime": "2026-10-19T11:12:23.303Z",
		"size": 415355,
		"path": "../public/assets/index-BsWgxSku.js"
	},
	"/assets/media-BpZmnJZ4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a6-Dw2wZboGdgbymSwyWt3T6RIoGy0\"",
		"mtime": "2026-10-19T11:12:23.395Z",
		"size": 5798,
		"path": "../public/assets/media-BpZmnJZ4.js"
	},
	"/assets/notices-CY8kM165.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a0-vHeA3t9Ic15VSjZL8EAw9TzHF+Q\"",
		"mtime": "2026-10-19T11:12:23.395Z",
		"size": 160,
		"path": "../public/assets/notices-CY8kM165.js"
	},
	"/assets/notifications-Ddtd1dx-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"799-iaXa1QeZEDB7WgZFBf+fNFa1/fg\"",
		"mtime": "2026-10-19T11:12:23.395Z",
		"size": 1945,
		"path": "../public/assets/notifications-Ddtd1dx-.js"
	},
	"/assets/pencil-BCEwK4iS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-HvqSQhifxSPhvfXMm467j2RI+Jc\"",
		"mtime": "2026-10-19T11:12:23.395Z",
		"size": 276,
		"path": "../public/assets/pencil-BCEwK4iS.js"
	},
	"/assets/Page-CIQhHxc4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"574-8qS6y0sQjfFat0FDeFg+3OPpL3U\"",
		"mtime": "2026-10-19T11:12:23.318Z",
		"size": 1396,
		"path": "../public/assets/Page-CIQhHxc4.js"
	},
	"/assets/plus-Clqs3nAE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-YBijawYtEd2UNLIayDW8zczaDu4\"",
		"mtime": "2026-10-19T11:12:23.397Z",
		"size": 153,
		"path": "../public/assets/plus-Clqs3nAE.js"
	},
	"/assets/polls-DpBsF_IV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-xXI9tXw9hLQOuuGeUDyeZ+mkBQQ\"",
		"mtime": "2026-10-19T11:12:23.408Z",
		"size": 158,
		"path": "../public/assets/polls-DpBsF_IV.js"
	},
	"/assets/react-COMFa4n5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2151-uPtNt8Cu9juOmvSdeeVgj11tPGI\"",
		"mtime": "2026-10-19T11:12:23.438Z",
		"size": 8529,
		"path": "../public/assets/react-COMFa4n5.js"
	},
	"/assets/portal-permissions-D7SIglOm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed-kVlzPmlIROm3osyPBa+2zS2wBH4\"",
		"mtime": "2026-10-19T11:12:23.408Z",
		"size": 237,
		"path": "../public/assets/portal-permissions-D7SIglOm.js"
	},
	"/assets/reset-password-CP57ktXi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"721-ZNukz+eozexhgj1Uo3QMSksq6XQ\"",
		"mtime": "2026-10-19T11:12:23.440Z",
		"size": 1825,
		"path": "../public/assets/reset-password-CP57ktXi.js"
	},
	"/assets/residents-BFYDJctq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f2b-zHaPt8HarlG2tcMhMj0GH24yDTw\"",
		"mtime": "2026-10-19T11:12:23.440Z",
		"size": 3883,
		"path": "../public/assets/residents-BFYDJctq.js"
	},
	"/assets/route-ByQBUQ9t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14b5-DkEDCHPT0trcG+++CpwcjguCe1Y\"",
		"mtime": "2026-10-19T11:12:23.440Z",
		"size": 5301,
		"path": "../public/assets/route-ByQBUQ9t.js"
	},
	"/assets/routes-7YzXeP7k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d70-0dcYTSycoVeWhGbLmTh6A4wsW5w\"",
		"mtime": "2026-10-19T11:12:23.440Z",
		"size": 7536,
		"path": "../public/assets/routes-7YzXeP7k.js"
	},
	"/assets/rules-BhiWokm-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-rJ3U0SIJ5QPjFQC4290QsUJYe98\"",
		"mtime": "2026-10-19T11:12:23.440Z",
		"size": 158,
		"path": "../public/assets/rules-BhiWokm-.js"
	},
	"/assets/search-D7kTqDS6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-t3R9rb0tckpWZo1urOjxmbINWTU\"",
		"mtime": "2026-10-19T11:12:23.442Z",
		"size": 174,
		"path": "../public/assets/search-D7kTqDS6.js"
	},
	"/assets/shopping-FxPTwJ9c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1-VC+h4JFBxck1XoXmqWMiQzoCbzU\"",
		"mtime": "2026-10-19T11:12:23.442Z",
		"size": 161,
		"path": "../public/assets/shopping-FxPTwJ9c.js"
	},
	"/assets/useQuery-BdPGL1oV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f28-q7FfeL1fgzyrgrR/4illGiSWR/4\"",
		"mtime": "2026-10-19T11:12:23.442Z",
		"size": 7976,
		"path": "../public/assets/useQuery-BdPGL1oV.js"
	},
	"/assets/trash-2-BE0TwpST.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-S+OcbLFbDQTioVd7f2473s4GYp8\"",
		"mtime": "2026-10-19T11:12:23.442Z",
		"size": 328,
		"path": "../public/assets/trash-2-BE0TwpST.js"
	},
	"/assets/users-q-xR6rLz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-gLWds+T089nBK8aYNfKCW34pmZk\"",
		"mtime": "2026-10-19T11:12:23.444Z",
		"size": 306,
		"path": "../public/assets/users-q-xR6rLz.js"
	},
	"/assets/utils-4jUIYOBc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6bed-90NGITyc+kEKvxUkUtkYHgO1XH4\"",
		"mtime": "2026-10-19T11:12:23.444Z",
		"size": 27629,
		"path": "../public/assets/utils-4jUIYOBc.js"
	},
	"/assets/wrench-BACC6QdI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cd-NDjlWWPPFMQbr2lbhUXMeOxIOKk\"",
		"mtime": "2026-10-19T11:12:23.444Z",
		"size": 973,
		"path": "../public/assets/wrench-BACC6QdI.js"
	},
	"/assets/styles-DT_p8plu.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"132b6-SYWFmAmv1fvCz7DiQo8eHiFxI1U\"",
		"mtime": "2026-10-19T11:12:23.444Z",
		"size": 78518,
		"path": "../public/assets/styles-DT_p8plu.css"
	},
	"/assets/user-round-Db7wSiDF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b6-YN3GYfluaIzmrYRCKxhnSGIgcWg\"",
		"mtime": "2026-10-19T11:12:23.444Z",
		"size": 182,
		"path": "../public/assets/user-round-Db7wSiDF.js"
	},
	"/assets/studio-BiaioRMr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"119f-gEKQb2Kf0oLY2967YKeAL9efdLQ\"",
		"mtime": "2026-10-19T11:12:23.442Z",
		"size": 4511,
		"path": "../public/assets/studio-BiaioRMr.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_i7qvuK = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_i7qvuK
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
